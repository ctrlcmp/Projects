﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgencijaZaPutovanja
{
    [Serializable]
    internal class Korisnik
    {
        private int Id;
        private string Ime;
        private string Prezime;
        private string KorisnickoIme;
        private string Sifra;
        private string vrsta_korisnika;
        Korisnik()
        {
            vrsta_korisnika = "Klijent";
        }
        public Korisnik(int id,string ime, string prezime, string korisnickoIme, string sifra,string vrsta)
        {
            Id1 = id;
            Ime = ime;
            Prezime = prezime;
            KorisnickoIme = korisnickoIme;
            Sifra = sifra;
            Vrsta_korisnika= vrsta;
        }
        
        public string Ime1 { get => Ime; set => Ime = value; }
        public string Prezime1 { get => Prezime; set => Prezime = value; }
        public string KorisnickoIme1 { get => KorisnickoIme; set => KorisnickoIme = value; }
        public string Sifra1 { get => Sifra; set => Sifra = value; }
        public string Vrsta_korisnika { get => vrsta_korisnika; set => vrsta_korisnika = value; }
        public int Id1 { get => Id; set => Id = value; }

        public override string ToString()
        {
            return "ID:"+Id1+" Ime: "+Ime + " Prezime:  " + Prezime + " Korisnicko Ime: " + KorisnickoIme + " Sifra: " +Sifra+" Vrsta Korisnika: "+vrsta_korisnika;
        }
    }
}
