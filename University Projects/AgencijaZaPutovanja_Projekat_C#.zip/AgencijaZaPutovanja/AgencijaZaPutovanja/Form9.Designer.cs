﻿namespace AgencijaZaPutovanja
{
    partial class Form9
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button3 = new System.Windows.Forms.Button();
            this.lblDatum = new System.Windows.Forms.Label();
            this.lblMesto = new System.Windows.Forms.Label();
            this.lblDrzava = new System.Windows.Forms.Label();
            this.lblUkupnoMesta = new System.Windows.Forms.Label();
            this.lblBrojDana = new System.Windows.Forms.Label();
            this.lblPopust = new System.Windows.Forms.Label();
            this.lblCena = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.txtUkupnoMesta = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCena = new System.Windows.Forms.TextBox();
            this.txtBrojDana = new System.Windows.Forms.TextBox();
            this.txtPopust = new System.Windows.Forms.TextBox();
            this.txtDrzava = new System.Windows.Forms.TextBox();
            this.txtMesto = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Red;
            this.button3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(238, 464);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(105, 38);
            this.button3.TabIndex = 67;
            this.button3.Text = "Fajl";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // lblDatum
            // 
            this.lblDatum.AutoSize = true;
            this.lblDatum.BackColor = System.Drawing.Color.OrangeRed;
            this.lblDatum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatum.Location = new System.Drawing.Point(132, 401);
            this.lblDatum.Name = "lblDatum";
            this.lblDatum.Size = new System.Drawing.Size(47, 15);
            this.lblDatum.TabIndex = 66;
            this.lblDatum.Text = "label6";
            // 
            // lblMesto
            // 
            this.lblMesto.AutoSize = true;
            this.lblMesto.BackColor = System.Drawing.Color.OrangeRed;
            this.lblMesto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMesto.Location = new System.Drawing.Point(132, 42);
            this.lblMesto.Name = "lblMesto";
            this.lblMesto.Size = new System.Drawing.Size(47, 15);
            this.lblMesto.TabIndex = 65;
            this.lblMesto.Text = "label6";
            // 
            // lblDrzava
            // 
            this.lblDrzava.AutoSize = true;
            this.lblDrzava.BackColor = System.Drawing.Color.OrangeRed;
            this.lblDrzava.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDrzava.Location = new System.Drawing.Point(132, 96);
            this.lblDrzava.Name = "lblDrzava";
            this.lblDrzava.Size = new System.Drawing.Size(47, 15);
            this.lblDrzava.TabIndex = 64;
            this.lblDrzava.Text = "label6";
            // 
            // lblUkupnoMesta
            // 
            this.lblUkupnoMesta.AutoSize = true;
            this.lblUkupnoMesta.BackColor = System.Drawing.Color.OrangeRed;
            this.lblUkupnoMesta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUkupnoMesta.Location = new System.Drawing.Point(132, 339);
            this.lblUkupnoMesta.Name = "lblUkupnoMesta";
            this.lblUkupnoMesta.Size = new System.Drawing.Size(55, 15);
            this.lblUkupnoMesta.TabIndex = 63;
            this.lblUkupnoMesta.Text = "label11";
            // 
            // lblBrojDana
            // 
            this.lblBrojDana.AutoSize = true;
            this.lblBrojDana.BackColor = System.Drawing.Color.OrangeRed;
            this.lblBrojDana.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBrojDana.Location = new System.Drawing.Point(132, 281);
            this.lblBrojDana.Name = "lblBrojDana";
            this.lblBrojDana.Size = new System.Drawing.Size(55, 15);
            this.lblBrojDana.TabIndex = 62;
            this.lblBrojDana.Text = "label10";
            // 
            // lblPopust
            // 
            this.lblPopust.AutoSize = true;
            this.lblPopust.BackColor = System.Drawing.Color.OrangeRed;
            this.lblPopust.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPopust.Location = new System.Drawing.Point(132, 214);
            this.lblPopust.Name = "lblPopust";
            this.lblPopust.Size = new System.Drawing.Size(47, 15);
            this.lblPopust.TabIndex = 61;
            this.lblPopust.Text = "label9";
            // 
            // lblCena
            // 
            this.lblCena.AutoSize = true;
            this.lblCena.BackColor = System.Drawing.Color.OrangeRed;
            this.lblCena.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCena.Location = new System.Drawing.Point(132, 151);
            this.lblCena.Name = "lblCena";
            this.lblCena.Size = new System.Drawing.Size(47, 15);
            this.lblCena.TabIndex = 60;
            this.lblCena.Text = "label6";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.PeachPuff;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(15, 464);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(105, 38);
            this.button2.TabIndex = 59;
            this.button2.Text = "Admin";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtUkupnoMesta
            // 
            this.txtUkupnoMesta.Location = new System.Drawing.Point(135, 316);
            this.txtUkupnoMesta.Multiline = true;
            this.txtUkupnoMesta.Name = "txtUkupnoMesta";
            this.txtUkupnoMesta.Size = new System.Drawing.Size(183, 20);
            this.txtUkupnoMesta.TabIndex = 58;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.Info;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(19, 316);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(106, 16);
            this.label8.TabIndex = 56;
            this.label8.Text = "Ukupno Mesta";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.Info;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(19, 382);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 16);
            this.label7.TabIndex = 55;
            this.label7.Text = "Datum";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Info;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(19, 258);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 16);
            this.label5.TabIndex = 54;
            this.label5.Text = "Broj Dana";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.Info;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(19, 191);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 53;
            this.label4.Text = "Popust";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Info;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(19, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 16);
            this.label3.TabIndex = 52;
            this.label3.Text = "Cena";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Info;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 16);
            this.label2.TabIndex = 51;
            this.label2.Text = "Drzava";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Info;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 16);
            this.label1.TabIndex = 49;
            this.label1.Text = "Mesto";
            // 
            // txtCena
            // 
            this.txtCena.Location = new System.Drawing.Point(135, 128);
            this.txtCena.Multiline = true;
            this.txtCena.Name = "txtCena";
            this.txtCena.Size = new System.Drawing.Size(183, 20);
            this.txtCena.TabIndex = 48;
            // 
            // txtBrojDana
            // 
            this.txtBrojDana.Location = new System.Drawing.Point(135, 258);
            this.txtBrojDana.Multiline = true;
            this.txtBrojDana.Name = "txtBrojDana";
            this.txtBrojDana.Size = new System.Drawing.Size(183, 20);
            this.txtBrojDana.TabIndex = 47;
            // 
            // txtPopust
            // 
            this.txtPopust.Location = new System.Drawing.Point(135, 191);
            this.txtPopust.Multiline = true;
            this.txtPopust.Name = "txtPopust";
            this.txtPopust.Size = new System.Drawing.Size(183, 20);
            this.txtPopust.TabIndex = 46;
            // 
            // txtDrzava
            // 
            this.txtDrzava.Location = new System.Drawing.Point(135, 73);
            this.txtDrzava.Multiline = true;
            this.txtDrzava.Name = "txtDrzava";
            this.txtDrzava.Size = new System.Drawing.Size(183, 20);
            this.txtDrzava.TabIndex = 45;
            // 
            // txtMesto
            // 
            this.txtMesto.Location = new System.Drawing.Point(135, 19);
            this.txtMesto.Multiline = true;
            this.txtMesto.Name = "txtMesto";
            this.txtMesto.Size = new System.Drawing.Size(183, 20);
            this.txtMesto.TabIndex = 44;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(135, 378);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 68;
            // 
            // Form9
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OrangeRed;
            this.ClientSize = new System.Drawing.Size(394, 513);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.lblDatum);
            this.Controls.Add(this.lblMesto);
            this.Controls.Add(this.lblDrzava);
            this.Controls.Add(this.lblUkupnoMesta);
            this.Controls.Add(this.lblBrojDana);
            this.Controls.Add(this.lblPopust);
            this.Controls.Add(this.lblCena);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.txtUkupnoMesta);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCena);
            this.Controls.Add(this.txtBrojDana);
            this.Controls.Add(this.txtPopust);
            this.Controls.Add(this.txtDrzava);
            this.Controls.Add(this.txtMesto);
            this.Name = "Form9";
            this.Text = "Izmeni Listu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label lblDatum;
        private System.Windows.Forms.Label lblMesto;
        private System.Windows.Forms.Label lblDrzava;
        private System.Windows.Forms.Label lblUkupnoMesta;
        private System.Windows.Forms.Label lblBrojDana;
        private System.Windows.Forms.Label lblPopust;
        private System.Windows.Forms.Label lblCena;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtUkupnoMesta;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCena;
        private System.Windows.Forms.TextBox txtBrojDana;
        private System.Windows.Forms.TextBox txtPopust;
        private System.Windows.Forms.TextBox txtDrzava;
        private System.Windows.Forms.TextBox txtMesto;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}