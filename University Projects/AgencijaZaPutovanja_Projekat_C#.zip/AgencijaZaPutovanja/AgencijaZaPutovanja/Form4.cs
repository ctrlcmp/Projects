﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgencijaZaPutovanja
{
    public partial class Form4 : Form
    {
        List<Korisnik> listaKorisnika = new List<Korisnik>();
        List<Izlet>ListaZaIzleta = new List<Izlet>();
        List<string> listaIzleta=new List<string>();
        List<Rezervacija>listaRezervacije=new List<Rezervacija>();
        TextBox VrstaNaloga= new TextBox();
        Form2 form2;
        Form1 form1;
        Form6 form6;
        Form8 form8;
        Form9 form9;
        public string curItem;
        string curIndex="";
        string curIndexIzlet = "";
        public bool BtnClicked;
        bool selektovanIndex = false;
        public Form4()
        {
            InitializeComponent();
            PostaviPropertiListBoxa();
        }
        // metode
        public List<string> ListaIzleta
        {
            get { return this.listaIzleta; }
        }
        public ListBox LbIzleti
        {
            get { return this.lbIzleti; }
        }
        public ListBox form4ListBox
        {
            get { return this.lbKorisnici; }
        }
        public ListBox LblIzleti
        {
            get { return this.lbIzleti; }
        }
        public void PostaviPropertiListBoxa()
        {
            lbKorisnici.HorizontalScrollbar = true;
            lbKorisnici.ScrollAlwaysVisible = true;

            lbRezervacije.HorizontalScrollbar = true;
            lbRezervacije.ScrollAlwaysVisible = true;

            lbIzleti.HorizontalScrollbar = true;
            lbIzleti.ScrollAlwaysVisible = true;
        }
        public void deserijalizacijaIzleta()
        {
            try
            {
                if (File.Exists("IZLETI.bin"))
                {
                    using (FileStream fajl = new FileStream(("IZLETI.bin"), FileMode.Open, FileAccess.Read))
                    {
                        BinaryFormatter binform = new BinaryFormatter();
                        while(fajl.Position<fajl.Length)
                        {
                            object objekat=binform.Deserialize(fajl);
                            Izlet izlet =(Izlet)objekat;
                            listaIzleta.Add(izlet.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void deserijalizulListaIzletTIPIZLET()
        {
            try
            {
                if (File.Exists("IZLETI.bin"))
                {
                    using (FileStream fajl = new FileStream(("IZLETI.bin"), FileMode.Open, FileAccess.Read))
                    {
                        BinaryFormatter binform = new BinaryFormatter();
                        while (fajl.Position < fajl.Length)
                        {
                            object objekat = binform.Deserialize(fajl);
                            Izlet izlet = (Izlet)objekat;
                            ListaZaIzleta.Add(izlet);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void PostaviLBLIzlete()
        {
            LblIzleti.DataSource = listaIzleta;
        }
        public void UbacivanjeUlistu()
        {
            listaKorisnika.Clear(); // Očistite listu pre dodavanja novih podataka
            if (File.Exists("nalog.bin"))
            {
                using (FileStream fajl = new FileStream("nalog.bin", FileMode.Open, FileAccess.Read))
                {
                    BinaryFormatter binform = new BinaryFormatter();
                    while (fajl.Position < fajl.Length)
                    {
                        Korisnik korisnik = (Korisnik)binform.Deserialize(fajl);
                        listaKorisnika.Add(korisnik);
                    }
                }
            }
        }
        public void UbacivanjeListeUfajl()
        {
            try
            {
               if(File.Exists("nalog.bin"))
                {
                    using (FileStream fajl = new FileStream(("nalog.bin"), FileMode.Create, FileAccess.Write))
                    {
                        BinaryFormatter binform= new BinaryFormatter();
                        foreach(Korisnik k in listaKorisnika)
                        {
                            binform.Serialize(fajl,k);
                        }
                    }
                }
            }
            catch(Exception ex)
            { 
              MessageBox.Show(ex.Message);
            }

        }
        public void UbacivanjeUIzletFajl()
        {
            try
            {
                if (File.Exists("IZLETI.bin"))
                {
                    using (FileStream fajl = new FileStream(("IZLETI.bin"), FileMode.Create, FileAccess.Write))
                    {
                        BinaryFormatter binform = new BinaryFormatter();
                        foreach(Izlet i in ListaZaIzleta)
                        {
                            binform.Serialize(fajl,i);
                        }
                        
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void DodavanjeUlabelu()
        { 
            UbacivanjeUlistu();
            lbKorisnici.Enabled = true;
            lbKorisnici.DataSource = listaKorisnika;
        }

        public void DeserijalizujRezervacije()
        {
                try
                {
                    if (File.Exists("rezervacije.bin"))
                    {
                        using (FileStream fajl = new FileStream(("rezervacije.bin"), FileMode.Open, FileAccess.Read))
                        {
                            BinaryFormatter binform = new BinaryFormatter();
                            while (fajl.Position < fajl.Length)
                            {
                                object objekat = binform.Deserialize(fajl);
                                Rezervacija rez = (Rezervacija)objekat;
                                listaRezervacije.Add(rez);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
         }
        public void staviNaListu()
        {
            lbRezervacije.DataSource = null;
            lbRezervacije.DataSource = listaRezervacije;
        }
        public void BrisiIzlet()
        {
            if(lbIzleti.SelectedIndex!=-1)
            {
                    foreach (Rezervacija rez in listaRezervacije)
                    {
                    if (rez.ID_izleta1 == ListaZaIzleta[lbIzleti.SelectedIndex].ID1)
                    {
                        button9.Enabled = false;
                        button8.Enabled = false;
                        button3.Enabled = false;
                    }
                    else
                    {
                        button9.Enabled = true;
                        button8.Enabled = true;
                        button3.Enabled = true;
                    }
                    }            
            }
            else button9.Enabled=false;
                    
        }
        public void BrisiKorisnika()
        {
            if (int.Parse(curIndex) != -1)
            {
                foreach (Rezervacija rez in listaRezervacije)
                {
                    if (rez.ID_korisnika1 == listaKorisnika[int.Parse(curIndex)].Id1)
                    {
                        button3.Enabled = false;
                    }
                    else button3.Enabled = true;
                }
            }
            else button3.Enabled = false;
        }
        // kraj metoda
        private void Form4_Load(object sender, EventArgs e)
        {
            DodavanjeUlabelu();
            deserijalizacijaIzleta();
            deserijalizulListaIzletTIPIZLET();
            PostaviLBLIzlete();
            DeserijalizujRezervacije();
            staviNaListu();
            timer1.Start(); 
            timer1.Enabled = true;
            BtnClicked = false;
            lbIzleti.SelectedIndex = -1;
            lbKorisnici.SelectedIndex = -1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (form2 == null || form2.IsDisposed)
            {
                form2 = new Form2(form1);
                form2.FormClosed += Form2_FormClosed;
            };
            form2.PrikaziSkriveniTextBox(true);
            form2.Show();
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            form2=null;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (form6 == null || form6.IsDisposed)
            {
                form6 = new Form6();
                form6.FormClosed += Form6_FormClosed;
            };
            if(int.Parse(curIndex)!=-1)
            form6.UpdateLabela(lbKorisnici.SelectedItem.ToString());
            form6.Show();
            this.Hide();
        }

        private void Form6_FormClosed(object sender, FormClosedEventArgs e)
        {
            form6 = null;
        }

        private void button3_Click(object sender, EventArgs e)
        {

                button3.Enabled = true;
                listaKorisnika.RemoveAt(int.Parse(curIndex));
                lbKorisnici.DataSource = null;
                lbKorisnici.DataSource = listaKorisnika;
                UbacivanjeListeUfajl();
                MessageBox.Show("Uspesno ste Izbrisali nalog");
        }

        private void lbKorisnici_SelectedIndexChanged(object sender, EventArgs e)
        {
            curIndex= lbKorisnici.SelectedIndex.ToString();
        }

        private void lbIzleti_SelectedIndexChanged(object sender, EventArgs e)
        {
            curIndexIzlet = lbIzleti.SelectedIndex.ToString();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            // obezbedjujem da samo kad je nesto selektovano sledi brisanje
            BrisiIzlet();
            BrisiKorisnika();
            if (int.Parse(curIndex) == -1)
            {
                selektovanIndex = false;
                button3.Enabled=false;
                button2.Enabled=false;

            }
            else
            {
                selektovanIndex = true;
                button3.Enabled=true;
                button2.Enabled=true;
            }
            if (int.Parse(curIndexIzlet) == -1)
            {
                button9.Enabled = false;
                button8.Enabled = false;
            }
            else
            {
                button9.Enabled = true;
                button8.Enabled = true;
            }
        }

        private void button3_MouseEnter(object sender, EventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (form8 == null || form8.IsDisposed)
            {
                form8 = new Form8();
                form8.FormClosed += Form8_FormClosed;      
            };
            form8.Show();
            this.Hide();
        }

        private void Form8_FormClosed(object sender, FormClosedEventArgs e)
        {
            form8= null;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if(form9==null||form9.IsDisposed)
            {
                form9 = new Form9();
                form9.FormClosed += Form9_FormClosed;
            }
            if (int.Parse(curIndexIzlet) != -1)
                form9.PoslatStringIzAdmina(lbIzleti.SelectedItem.ToString());
            form9.Show();
            this.Hide();
        }

        private void Form9_FormClosed(object sender, FormClosedEventArgs e)
        {
            form9 = null;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            ListaZaIzleta.RemoveAt(int.Parse(curIndexIzlet));
            lbIzleti.DataSource = null;
            lbIzleti.DataSource = ListaZaIzleta;
            UbacivanjeUIzletFajl();
            MessageBox.Show("Uspesno ste Izbrisali nalog");
        }

        private void panel1_Click(object sender, EventArgs e)
        {
            lbIzleti.SelectedIndex = -1;
        }

        private void panel2_Click(object sender, EventArgs e)
        {
            lbKorisnici.SelectedIndex = -1;
        }
    }
}
