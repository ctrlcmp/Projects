﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgencijaZaPutovanja
{
    public partial class Form6 : Form
    {
        List<Korisnik> lista = new List<Korisnik>();
        Form4 form4 = new Form4();
        string nalog;
        string[] niz;
        string[] delovi;
        string id,ime;
        bool mozes_menjati = false;
        public Form6()
        {
            InitializeComponent();
        }
        public void UpdateLabela(string text)
        {
            string nalog = text;
            delovi = nalog.Split(' ');
            id = delovi[0].Split(':')[1];
        }
        public bool proveraTextBoxa()
        {
            if (!string.IsNullOrEmpty(txtIme.Text) && !string.IsNullOrEmpty(txtPrezime.Text) && !string.IsNullOrEmpty(txtUsername.Text) && !string.IsNullOrEmpty(txtSifra.Text)
                && !string.IsNullOrEmpty(txtVrstaNaloga.Text)) return true;
            else return false;
        }
        public void ListaKorisnika()
        {
            foreach (Korisnik k in lista)
            {
                if (k.Id1 == int.Parse(id))
                {
                    k.Ime1 = txtIme.Text;
                    k.Prezime1 = txtPrezime.Text;
                    k.KorisnickoIme1 = txtUsername.Text;
                    k.Sifra1 = txtSifra.Text;
                    k.Vrsta_korisnika = txtVrstaNaloga.Text;
                }
            }
        }
        private void Form6_Load(object sender, EventArgs e)
        {
            listBox1.HorizontalScrollbar = true;
            listBox1.ScrollAlwaysVisible = true;
            listBox1.HorizontalScrollbar = true;
            timer1.Enabled = true;
            timer1.Start();
            OtvaranjeFajla();

            
        }
        public void OtvaranjeFajla()
        {
            lista.Clear(); // Očistite listu pre dodavanja novih podataka
            if (File.Exists("nalog.bin"))
            {
                using (FileStream fajl = new FileStream("nalog.bin", FileMode.Open, FileAccess.Read))
                {
                    BinaryFormatter binform = new BinaryFormatter();
                    while (fajl.Position < fajl.Length)
                    {
                        // Deserijalizujte svaki pojedinačni objekat i dodajte ga u listu
                        Korisnik korisnik = (Korisnik)binform.Deserialize(fajl);
                        lista.Add(korisnik);
                    }
                }
            }
        }

        public void pisanjeUfajl()
        {
            try
            {
                using (FileStream fajl = new FileStream("nalog.bin", FileMode.Create, FileAccess.Write))
                {
                    BinaryFormatter binform = new BinaryFormatter();
                    foreach (Korisnik korisnik in lista)
                    {
                        binform.Serialize(fajl, korisnik);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
 
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // OBEZBEDI da ne moze dvaput ista promena da se napravi
            ListaKorisnika();
            pisanjeUfajl();
            form4.form4ListBox.DataSource = null;
            form4.form4ListBox.DataSource = lista;
            listBox1.DataSource = lista;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!proveraTextBoxa())
            {
                button1.Enabled = false;
            }
            else button1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            if(form4==null || form4.IsDisposed)
            {
                form4=new Form4();
                form4.FormClosed += Form4_FormClosed;
            }
            form4.Show();
        }

        private void Form4_FormClosed(object sender, FormClosedEventArgs e)
        {
           form4= null;
        }
    }
}
