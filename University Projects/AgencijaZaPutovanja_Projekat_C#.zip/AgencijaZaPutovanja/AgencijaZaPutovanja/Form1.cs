﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace AgencijaZaPutovanja
{
    public partial class Form1 : Form
    {
        List<Korisnik>ListaKorisnika=new List<Korisnik>();
        TextBox trenutniTextBox;
        Form2 form2;
        Form3 form3;
        Form5 form5=new Form5();
        public int Id_Usera;
        // Prvi admin najglavniji akaunt !!!
        Korisnik prviAdmin = new Korisnik(0, "prvi", "prvi", "admin", "admin", "admin");
        string username,
            password;
        int flag = 0;
        public int vr;
        public int Id_usera
        {
            get { return vr; }
        }

        public Form1()
        {
            InitializeComponent();
            form2 = new Form2(this);
            timer1.Start();
            timer1.Enabled = true;   
        }
        // metode
        public bool ProveraNaloga()
        {
            try
            {
                using (FileStream fajl = new FileStream("nalog.bin", FileMode.Open, FileAccess.Read))
                {
                    BinaryFormatter binform = new BinaryFormatter();
                    // dok je pozicija koju iscitava manja od njegove duzine(kraj fajla!) 
                    while (fajl.Position < fajl.Length)
                    {
                        object Object = binform.Deserialize(fajl);
                        if (Object is Korisnik)
                        {
                            // vrsimo konverziju objekta u tip nalog
                            Korisnik pomocni = (Korisnik)Object;
                            username = pomocni.KorisnickoIme1;
                            password = pomocni.Sifra1;
                            if (txtUsername.Text == username) lblKorisnik.Text = "";
                            if (txtSifra.Text == password) lblSifraa.Text = "";
                            if (txtUsername.Text == username && txtSifra.Text == password)
                            {
                                return true;
                            };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public void LabelaUsernameSifra()
        {
            if (string.IsNullOrEmpty(txtUsername.Text) || txtUsername.Text == "Korisnicko ime") lblKorisnik.Text = "";
            else
            {
                if (txtUsername.Text != username)lblKorisnik.Text = "Nije ispravno uneseno Korisnicko Ime";
            }
            if (string.IsNullOrEmpty(txtSifra.Text) || txtSifra.Text == "Sifra") lblSifraa.Text = "";
            else
            {
                if (txtSifra.Text != password) lblSifraa.Text = "Nije ispravna sifra";
            }
        }

        public void ResetTextBoxa(TextBox t)
        {
            t.BackColor = Color.FromArgb(255, 192, 192);
            t.BorderStyle = BorderStyle.None;
            if (t == txtUsername)
            {
                t.Text = "Korisnicko ime";
            }
            else 
            {
                t.Text = "Sifra";
                // Ukida mi se "Sifrovana" poruka na tekstboxu Sifra
                t.PasswordChar = '\0';
            }
        }
        public void CapsLock()
        {
            bool CapsLock=Control.IsKeyLocked(Keys.CapsLock);
            if (CapsLock)
            {
                lblCaps.Text = "Caps Lock ukljucen";
            }
            else
            {
                lblCaps.Text = "";
            }
        }

        public void SerijalizacijaAdmina()
        {
            try
            {
                // Proveravamo da li fajl postoji
                if (!File.Exists("nalog.bin"))
                {
                    // Kreiramo fajl ako ne postoji
                    using (FileStream fajl = File.Create("nalog.bin"))
                    {
                        BinaryFormatter binform = new BinaryFormatter();
                        // Serijalizujemo prviAdmin objekat
                        binform.Serialize(fajl, prviAdmin);
                    }
                }
                else
                {
                    // Fajl postoji, proveravamo da li prviAdmin već postoji u fajlu
                    bool adminPostoji = false;
                    using (FileStream fajl = new FileStream("nalog.bin", FileMode.Open, FileAccess.Read))
                    {
                        BinaryFormatter binform = new BinaryFormatter();
                        while (fajl.Position < fajl.Length)
                        {
                            Korisnik nalog = (Korisnik)binform.Deserialize(fajl);
                            if (nalog.KorisnickoIme1 == prviAdmin.KorisnickoIme1)
                            {
                                adminPostoji = true;
                                break;
                            }
                        }
                    }

                    // Ako prviAdmin ne postoji, serijalizujemo ga
                    if (!adminPostoji)
                    {
                        using (FileStream fajl = new FileStream("nalog.bin", FileMode.Append))
                        {
                            BinaryFormatter binform = new BinaryFormatter();
                            binform.Serialize(fajl, prviAdmin);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void DeserijalizujUListu()
        {
            try
            {
                if(File.Exists("nalog.bin"))
                {
                    using (FileStream fajl = new FileStream("nalog.bin", FileMode.Open, FileAccess.Read))
                    {
                        BinaryFormatter binform = new BinaryFormatter();
                        while (fajl.Position < fajl.Length)
                        {
                            object Object = binform.Deserialize(fajl);
                            Korisnik k = (Korisnik)Object;
                            ListaKorisnika.Add(k);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        // kraj metoda
        private void txtUsername_Click_1(object sender, EventArgs e)
        {
            form2.SetovanjeTextBoxa(txtUsername);
            trenutniTextBox = txtUsername;
        }
        private void txtSifra_Click_1(object sender, EventArgs e)
        {
            form2.SetovanjeTextBoxa(txtSifra);
            txtSifra.PasswordChar = '*';
            trenutniTextBox = txtSifra;
        }

        private void panel1_Click_1(object sender, EventArgs e)
        {
            // Dok ne kliknem na neki tekstbox ne poziva se metoda
            // nece biti NullReference greske
            if(trenutniTextBox!=null)
            ResetTextBoxa(trenutniTextBox);
        }
        private void tbp1_Click(object sender, EventArgs e)
        {
            if (trenutniTextBox != null)
                ResetTextBoxa(trenutniTextBox);
        }
        private void panel2_MouseEnter_1(object sender, EventArgs e)
        {
            if (flag == 1)
            {
                panel2.Cursor = Cursors.No;
            }
            else
            {
                panel2.Cursor = Cursors.Hand;
            }
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void label2_Click_1(object sender, EventArgs e)
        {
            //Ako ugasimo formu ili ako ne postoji stvaramo njenu instancu
            // i zatim kada se ugasi forma postavljamo njenu referencu na null -> oslobadjamo je iz memorije
            // ovo nam omogucava da je otvaramo i zatvaramo bezbroj puta
            if (form2 == null || form2.IsDisposed)
            {
                form2 = new Form2(this);
                form2.FormClosed += Form2_FormClosed;
            }
            form2.Show();
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            form2 = null;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            LabelaUsernameSifra();
            CapsLock();
            if (checkBox1.Checked == true)
            {
                txtSifra.PasswordChar = '\0';
            }
            else if (txtSifra.Text != "Sifra" && checkBox1.Checked==false)
            {
                txtSifra.PasswordChar = '*';
            }
            if (!ProveraNaloga())
            {
                if (flag == 0)
                {
                    button1.BackColor = Color.Red;
                    button1.Enabled = false;
                    flag = 1;
                }
            }
            else
            {
                if (flag == 1)
                {
                    button1.Enabled = true;
                    button1.BackColor = Color.Green;
                    flag = 0;
                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if(chbAdmin.Checked==false)
            {
                // saljemo id formi5
                DeserijalizujUListu();
                foreach (Korisnik k in ListaKorisnika)
                {
                    if (k.Sifra1 == txtSifra.Text)
                    {
                        //MessageBox.Show(k.Id1.ToString());
                        //MessageBox.Show(k.Id1.ToString());
                        form5.uzmiId(k.Id1);
                        vr = k.Id1;
                        break;
                    }
                }
                if (form5 == null || form5.IsDisposed)
                {
                    form5 = new Form5();
                    form5.FormClosed += Form5_FormClosed;
                }
                form5.Show();
            }
            else
            {
                if (form3 == null || form3.IsDisposed)
                {
                    form3 = new Form3(form2,this);
                    form3.FormClosed += Form3_FormClosed;
                }
                form3.Show();
            }
        }

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            form3 = null;
        }

        private void Form5_FormClosed(object sender, FormClosedEventArgs e)
        {
            form5 = null;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            SerijalizacijaAdmina();
        }


        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }


    }
}
