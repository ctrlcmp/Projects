﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgencijaZaPutovanja
{
    [Serializable]
    internal class Datumi
    {
        private int iDKorisnika;
        private int iDIzleta;
        private DateTime datumRezervacije;

        public int IDKorisnika { get => iDKorisnika; set => iDKorisnika = value; }
        public int IDIzleta { get => iDIzleta; set => iDIzleta = value; }
        public DateTime DatumRezervacije { get => datumRezervacije; set => datumRezervacije = value; }

        public Datumi(int iDKorisnika, int iDIzleta, DateTime datumRezervacije)
        {
            IDKorisnika = iDKorisnika;
            IDIzleta = iDIzleta;
            DatumRezervacije = datumRezervacije;
        }
    }
}
