﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgencijaZaPutovanja
{
    public class ID_REZ
    {
        public int ID;

        public ID_REZ(int iD)
        {
            ID1 = iD;
        }

        public int ID1 { get => ID; set => ID = value; }
    }
}
