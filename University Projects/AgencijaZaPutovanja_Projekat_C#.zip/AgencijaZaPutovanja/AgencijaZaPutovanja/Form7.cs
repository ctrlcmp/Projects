﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgencijaZaPutovanja
{
    public partial class Form7 : Form
    {
        List<string> listaIzleta = new List<string>();
        List<string> listaIzletaBezId = new List<string>();
        List<string> ListaIzletaMesto = new List<string>();
        List<Izlet> Izleti = new List<Izlet>();
        List<Rezervacija> listaRezervacija = new List<Rezervacija>();
        List<Datumi> PomocnaLista = new List<Datumi>();
        Form5 form5=new Form5();
        string bezId,
            popust = "123";
        string Filtriranje = "",
            curItem = "";
        bool nasao = false,
            flag = false;
        Rezervacija rezervacija;
        int Id_izleta,
            trenutnaVR, ID123;
        double UkupnaCena = 0;
        DateTime datum;
        int IzletId;
        Datumi datumi1;
        public Form7()
        {
            InitializeComponent();
            SetListBox();
            //Punimo listu za izlete
            deserijalizujIzlete();
            izbacivanjeId();
            //Punimo listu za rezervacije
            DeserijalizacijaObjektaUlistu();
            //Punimo Pomocnu listu
            deserijalizujDatume();
            lbIzleti.DataSource = null;
            lbIzleti.DataSource = listaIzletaBezId;
            timer1.Start();
            timer1.Enabled = true;
        }
        // metode
        public void NasId(int x)
        {
            ID123 = x;
        }
        public void deserijalizujIzlete()
        {
            try
            {
                if (File.Exists("IZLETI.bin"))
                {
                    using (FileStream fajl = new FileStream(("IZLETI.BIN"), FileMode.Open, FileAccess.Read))
                    {
                        BinaryFormatter binform = new BinaryFormatter();
                        while (fajl.Position < fajl.Length)
                        {
                            object objekat = binform.Deserialize(fajl);
                            Izlet izlet = (Izlet)objekat;
                            Izleti.Add(izlet);
                            listaIzleta.Add(izlet.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void izbacivanjeId()
        {
            foreach (string s in listaIzleta)
            {

                bezId = s.Remove(0, 12);
                listaIzletaBezId.Add(bezId);
            }
        }
        public void PrikaziSamoIzletMesto()
        {
            string Mesto = txtMesto.Text;
            ListaIzletaMesto.Clear();
            foreach (string s in listaIzletaBezId)
            {
                if (s.Contains(Mesto))
                {
                    ListaIzletaMesto.Add(s);
                    nasao = true;
                }
            }
        }
        public void PostaviNaListBox()
        {
            lbIzleti.DataSource = null;
            lbIzleti.DataSource = ListaIzletaMesto;
        }
        public bool proveraTextBoxa()
        {
            if (!string.IsNullOrEmpty(txtMesto.Text)) return true;
            else return false;
        }
        public void SetListBox()
        {
            lbIzleti.ScrollAlwaysVisible = true;
            lbIzleti.HorizontalScrollbar = true;
        }
        public void BrojLjudi()
        {
            if (!string.IsNullOrEmpty(txtBroj.Text))
            {
                if (int.TryParse(txtBroj.Text, out trenutnaVR))
                {
                    if (lbIzleti.SelectedIndex != -1)
                    {
                        if (trenutnaVR != 0)
                        {
                            if (trenutnaVR < Izleti[lbIzleti.SelectedIndex].Ukupno_mesta)
                            {
                                lblBroj.Text = "";
                                button1.Enabled = true;
                            }
                            else if (trenutnaVR < 0)
                            {
                            }
                            else
                            {
                                lblBroj.Text = "Nema toliko mesta!";
                                button1.Enabled = false;
                            }
                        }
                        else
                        {
                            lblBroj.Text = "Nepravilan unos!";
                            button1.Enabled = false;
                        }
                    }
                }
                else
                {
                    lblBroj.Text = "Unos mora biti broj!";
                    button1.Enabled = false;
                }
            }
            else
            {
                lblBroj.Text = "";
            }
        }
        public int UzmiIzletId()
        {
            return Izleti[lbIzleti.SelectedIndex].ID1;
        }
        public void UzmiUkupnuCenu()
        {
            if (lbIzleti.SelectedIndex != -1)
            {
                UkupnaCena = Izleti[lbIzleti.SelectedIndex].Cena;
            }
            else UkupnaCena = 0;
            lblCena.Text = UkupnaCena.ToString();
        }
        public DateTime UzmiDatumIzIzleta()
        {
            return Izleti[lbIzleti.SelectedIndex].Datum;
        }
        public void kreirajObjekatRezervacije()
        {
            if (lbIzleti.SelectedIndex != -1)
            {
                rezervacija = new Rezervacija(ID123,IzletId, UkupnaCena, trenutnaVR, DateTime.Now, DateTime.Now);
                datumi1 = new Datumi(ID123,IzletId, datum);
            }
        }
        public void serijalizujDatume()
        {
            try
            {
                if (File.Exists("datumi.bin"))
                {
                    using (FileStream fajl = new FileStream(("datumi.BIN"), FileMode.Append))
                    {
                        BinaryFormatter binform = new BinaryFormatter();
                        binform.Serialize(fajl, datumi1);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void deserijalizujDatume()
        {
            try
            {
                if (File.Exists("datumi.bin"))
                {
                    using (FileStream fajl = new FileStream(("datumi.BIN"), FileMode.Open, FileAccess.Read))
                    {
                        BinaryFormatter binform = new BinaryFormatter();
                        while (fajl.Position < fajl.Length)
                        {
                            object Objekat = binform.Deserialize(fajl);
                            Datumi d = (Datumi)Objekat;
                            PomocnaLista.Add(d);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void SerijalizujObjekatURezervaciju()
        {
            try
            {
                if (File.Exists("rezervacije.bin"))
                {
                    using (FileStream fajl = new FileStream(("rezervacije.bin"), FileMode.Append))
                    {
                        BinaryFormatter binform = new BinaryFormatter();
                        // Metoda koja nam kreira objekat
                        kreirajObjekatRezervacije();
                        binform.Serialize(fajl, rezervacija);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void DeserijalizacijaObjektaUlistu()
        {
            try
            {
                if (File.Exists("rezervacije.bin"))
                {
                    using (FileStream fajl = new FileStream(("rezervacije.bin"), FileMode.Open, FileAccess.Read))
                    {
                        BinaryFormatter binform = new BinaryFormatter();
                        while (fajl.Position < fajl.Length)
                        {
                            object objekat = binform.Deserialize(fajl);
                            Rezervacija rez = (Rezervacija)objekat;
                            listaRezervacija.Add(rez);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void button3_Click_1(object sender, EventArgs e)
        {
            lbIzleti.DataSource = null;
            PrikaziSamoIzletMesto();
            PostaviNaListBox();
        }


        private void Form5_FormClosed(object sender, FormClosedEventArgs e)
        {
            form5 = null;
        }



        private void lbIzleti_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            UzmiUkupnuCenu();
            if (lbIzleti.SelectedIndex != -1)
            {
                lblCena.Text = UkupnaCena.ToString("F2");
                // dobijam datum iz liste kada se klikne lista
                datum = UzmiDatumIzIzleta();
                IzletId = UzmiIzletId();
            }
        }
        private void button2_Click_1(object sender, EventArgs e)
        {
            if (form5 == null || form5.IsDisposed)
            {
                form5 = new Form5();
                form5.FormClosed += Form5_FormClosed;
            }
            form5.Show();
            this.Hide();
        }

        private void txtBroj_TextChanged_1(object sender, EventArgs e)
        {
            if (lbIzleti.SelectedIndex != -1)
            {
                UkupnaCena = Izleti[lbIzleti.SelectedIndex].Cena;
                if (int.TryParse(txtBroj.Text, out int brojLjudi) && brojLjudi > 0)
                {
                    UkupnaCena *= brojLjudi; // Množimo cenu sa brojem ljudi
                }
                if (!string.IsNullOrEmpty(txtPopust.Text) && txtPopust.Text == popust && Izleti[lbIzleti.SelectedIndex].Popust > 0)
                {
                    double popustVrednost = Izleti[lbIzleti.SelectedIndex].Popust / 100.0;
                    UkupnaCena *= (1 - popustVrednost); // Primena popusta na ukupnu cenu
                }
            }

            lblCena.Text = UkupnaCena.ToString("F2");
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void lblNeg_Click(object sender, EventArgs e)
        {

        }

        private void txtPopust_TextChanged(object sender, EventArgs e)
        {
            if (lbIzleti.SelectedIndex != -1)
            {
                UkupnaCena = Izleti[lbIzleti.SelectedIndex].Cena;
                if (int.TryParse(txtBroj.Text, out int brojLjudi) && brojLjudi > 0)
                {
                    UkupnaCena *= brojLjudi; // Množimo cenu sa brojem ljudi
                }
                if (!string.IsNullOrEmpty(txtPopust.Text) && txtPopust.Text == popust && Izleti[lbIzleti.SelectedIndex].Popust > 0)
                {
                    double popustVrednost = Izleti[lbIzleti.SelectedIndex].Popust / 100.0;
                    UkupnaCena *= (1 - popustVrednost); // Primena popusta na ukupnu cenu
                }
            }

            lblCena.Text = UkupnaCena.ToString("F2");
        }

        public void Plati()
        {
            bool rezervacijaPostoji = false;

            // Proveravamo sve postojeće rezervacije za trenutnog korisnika
            foreach (Rezervacija rez in listaRezervacija)
            {
                if (rez.ID_korisnika1 == ID123)
                {
                    // Proveravamo da li korisnik već ima rezervaciju za isti izlet
                    if (rez.ID_izleta1 == IzletId)
                    {
                        rezervacijaPostoji = true;
                        button1.Text = "Vec rezervisano";
                        button1.Enabled = false;
                        break;
                    }

                    // Proveravamo da li korisnik ima rezervaciju za različit izlet na isti datum
                    foreach (Datumi d in PomocnaLista)
                    {
                        if (d.IDIzleta != IzletId && d.DatumRezervacije == datum.Date)
                        {
                            rezervacijaPostoji = true;
                            button1.Text = "Vec popunjen Datum";
                            button1.Enabled = false;
                            break;
                        }
                    }
                }

                if (rezervacijaPostoji)
                {
                    break;
                }
            }

            // Ako nema poklapanja, omogućavamo rezervaciju
            if (!rezervacijaPostoji)
            {
                button1.Enabled = true;
                button1.Text = "Potvrdi Rezervaciju";
            }
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            lbIzleti.SelectedItem = null;
            lbIzleti.SelectedIndex = -1;
            //MessageBox.Show(ID123.ToString());
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            SerijalizujObjekatURezervaciju();
            serijalizujDatume();
            MessageBox.Show("Uspesno izvrsena rezervacija!");
            if (form5 == null || form5.IsDisposed)
            {
                form5 = new Form5();
                form5.FormClosed += Form5_FormClosed;
            }
            form5.Show();
            this.Hide();

        }
        private void timer1_Tick_1(object sender, EventArgs e)
        {
            BrojLjudi();
            if (proveraTextBoxa())
            {
                if (!flag)
                    button3.Enabled = true;
                flag = true;
            }
            else
            {
                button3.Enabled = false;
                if (flag)
                {
                    lbIzleti.DataSource = null;
                    lbIzleti.DataSource = listaIzletaBezId;
                }
                flag = false;
            }
            Plati();
        }
    }
}
