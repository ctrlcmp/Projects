﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgencijaZaPutovanja
{
    public partial class Form3 : Form
    {
        string sifra = "Admin123";
        Form1 form1;
        Form2 form2;
        Form4 form4;
        int flag = 0;
        public Form3(Form2 form2, Form1 form1)
        {
            InitializeComponent();
            timer1.Start();
            timer1.Enabled = true;
            this.form2 = form2;
            this.form1 = form1;
        }
        //metode      

        //kraj metoda
        private void button1_Click(object sender, EventArgs e)
        {
            
            if(form4==null || form4.IsDisposed)
            {
                form4 = new Form4();
                form4.FormClosed += Form4_FormClosed;
            }
            form4.Show();
        }

        private void Form4_FormClosed(object sender, FormClosedEventArgs e)
        {
            form4 = null;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (textBox1.Text != sifra)
            {
                flag = 0;
                button1.Enabled = false;
            }
            else
            {
                flag = 1;
                button1.Enabled = true;
            }
        }

        private void panel1_MouseEnter(object sender, EventArgs e)
        {
            if(flag==0)
            {
                panel1.Cursor = Cursors.No;
            }
            else
            {
                panel1.Cursor = Cursors.Hand;
            }
        }
    }

}
