﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace AgencijaZaPutovanja
{
    [Serializable]
    internal class Rezervacija
    {
        int ID_korisnika;
        int ID_izleta;
        double ukupna_cena;
        int broj_rezervisanih_mesta;
        DateTime datum;
        DateTime vreme;

        public Rezervacija(int iD_korisnika, int iD_izleta, double ukupna_cena, int broj_rezervisanih_mesta, DateTime datum, DateTime vreme)
        {
            ID_korisnika1 = iD_korisnika;
            ID_izleta1 = iD_izleta;
            this.Ukupna_cena = ukupna_cena;
            this.Broj_rezervisanih_mesta = broj_rezervisanih_mesta;
            this.Datum = datum;
            this.Vreme = vreme;
        }

        public int ID_korisnika1 { get => ID_korisnika; set => ID_korisnika = value; }
        public int ID_izleta1 { get => ID_izleta; set => ID_izleta = value; }
        public double Ukupna_cena { get => ukupna_cena; set => ukupna_cena = value; }
        public int Broj_rezervisanih_mesta { get => broj_rezervisanih_mesta; set => broj_rezervisanih_mesta = value; }
        public DateTime Datum { get => datum; set => datum = value; }
        public DateTime Vreme { get => vreme; set => vreme = value; }

        public override string ToString()
        {
            return "ID_korisnika:" + ID_korisnika + " ID_izleta: " + ID_izleta + " Ukupna Cena:  " + Ukupna_cena + " Broj rezervisanih mesta: " + Broj_rezervisanih_mesta + " Datum " + datum.ToString("dd-mm-yyyy") + " Vreme rezervacije " + vreme.ToString("HH:mm:ss");
        }




    }
}
