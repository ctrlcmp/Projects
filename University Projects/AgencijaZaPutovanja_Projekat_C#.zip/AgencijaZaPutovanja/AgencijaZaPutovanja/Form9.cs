﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgencijaZaPutovanja
{
    public partial class Form9 : Form
    {
        List<Izlet>listaIzleta=new List<Izlet>();
        Form4 form4 = new Form4();
        Form8 form8=new Form8();
        string tekst="";
        string podeli,
            id;
        DateTime datum;
        public Form9()
        {
            InitializeComponent();
            // deserijalizujemo u listu objekata
            NapuniListu();
            timer1.Start();
            timer1.Enabled = true;
        }

        public void PoslatStringIzAdmina(string text)
        {
            tekst= text;
            // indeks
            id= text.Substring(3, 4);
        }
        public void NapuniListu()
        {
            try
            {
                if (File.Exists("IZLETI.bin"))
                {
                    using (FileStream fajl = new FileStream(("IZLETI.bin"), FileMode.Open, FileAccess.Read))
                    {
                        BinaryFormatter binform = new BinaryFormatter();
                        while (fajl.Position < fajl.Length)
                        {
                            object objekat = binform.Deserialize(fajl);
                            Izlet izlet = (Izlet)objekat;
                            listaIzleta.Add(izlet);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public bool ProveraTextBoxova()
        {
            if (!string.IsNullOrEmpty(txtMesto.Text) && !string.IsNullOrEmpty(txtDrzava.Text) && !string.IsNullOrEmpty(txtCena.Text) && !string.IsNullOrEmpty(txtPopust.Text) &&
                !string.IsNullOrEmpty(txtBrojDana.Text) && !string.IsNullOrEmpty(txtUkupnoMesta.Text)) return true;
            else
            {
                lblMesto.Text = "";
                lblDrzava.Text = "";
                lblCena.Text = "";
                lblPopust.Text = "";
                lblBrojDana.Text = "";
                lblUkupnoMesta.Text = "";
                return false;
            }
        }

        public void IzmeniListu()
        {
            foreach(Izlet i in listaIzleta)
            {
                if(i.ID1 == int.Parse(id))
                {
                    i.Mesto = txtMesto.Text;
                    i.Država = txtDrzava.Text;
                    i.Cena = double.Parse(txtCena.Text);
                    i.Popust= double.Parse(txtPopust.Text);
                    i.Broj_dana= int.Parse(txtBrojDana.Text);
                    i.Ukupno_mesta= int.Parse(txtUkupnoMesta.Text);
                    i.Datum=datum;
                }
            }
        }
        public bool ProveraStringova()
        {
            if(form8.String(txtMesto,lblMesto) && form8.String(txtDrzava, lblDrzava))return true;
            else return false;
        }
        // nije radilo ako se pozove form8.NeMozeBitiBroj() moralo je da se iskopira
        public bool NeMozeBitiBroj()
        {
            bool validacija = true;
                if (double.TryParse(txtCena.Text, out double rez))
            {
                if (rez < 0)
                {
                    lblCena.Text = "Vrednost ne sme biti negativna!";
                    validacija = false;
                }
                else lblCena.Text = "";
            }
            else
            {
                lblCena.Text = "Unos mora biti broj!";
                validacija = false;
            }

                if (double.TryParse(txtPopust.Text,out double  r))
                {
                    if (r < 0)
                    {
                        lblPopust.Text = "Vrednost ne sme biti negativna!";
                        validacija = false;
                    }
                    else lblPopust.Text = "";
                }
                else
                {
                    lblPopust.Text = "Unos mora biti broj!";
                    validacija = false;
                }

                if (int.TryParse(txtBrojDana.Text, out int re))
                {
                    if (re < 0)
                    {
                        lblBrojDana.Text = "Vrednost ne sme biti negativna!";
                        validacija = false;
                    }
                    else lblBrojDana.Text = "";
                }
                else
                {
                    lblBrojDana.Text = "Unos mora biti broj!";
                    validacija = false;
                }

                if (int.TryParse(txtUkupnoMesta.Text, out int rezz))
                {
                    if (rezz < 0)
                    {
                        lblUkupnoMesta.Text = "Vrednost ne sme biti negativna!";
                        validacija = false;
                    }
                    else lblUkupnoMesta.Text = "";
                }
                else
                {
                    lblUkupnoMesta.Text = "Unos mora biti broj!";
                    validacija = false;
                }
            datum = dateTimePicker1.Value;
            if (datum.Date > DateTime.Today)
            {
                lblDatum.Text = "";
                validacija = true;
            }
            else
            {
                lblDatum.Text = "Pogresan datum!";
                validacija = false; 
            }
            return validacija;
        }
        public void serijalizuj()
        {
            try
            {
                if (File.Exists("IZLETI.bin"))
                {
                    using (FileStream fajl = new FileStream(("IZLETI.bin"), FileMode.Create, FileAccess.Write))
                    {
                        BinaryFormatter binform = new BinaryFormatter();
                        foreach(Izlet i in listaIzleta)
                        {
                            binform.Serialize(fajl, i);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if(form4==null||form4.IsDisposed)
            {
                form4=new Form4();
                form4.FormClosed += Form4_FormClosed;
            }
            form4.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // sad smo izmenili vrednost u listi
            IzmeniListu();
            serijalizuj();  
            //form4.LbIzleti.DataSource = null;
            //form4.LbIzleti.DataSource = listaIzleta;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (ProveraTextBoxova())
            {
                if ( ProveraStringova() && NeMozeBitiBroj())
                    button3.Enabled = true;
                else button3.Enabled = false;
            }
            else button3.Enabled = false;
        }

        private void Form4_FormClosed(object sender, FormClosedEventArgs e)
        {
            form4 = null;
        }
    }
}
