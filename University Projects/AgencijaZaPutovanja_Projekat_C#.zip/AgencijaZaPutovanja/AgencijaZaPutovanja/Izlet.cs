﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgencijaZaPutovanja
{
    [Serializable]
    internal class Izlet
    {
        int ID;
        string mesto;
        string drzava;
        double cena;
        double popust;
        int  broj_dana; 
        int  ukupno_mesta; 
        DateTime  datum;
        public Izlet(int iD, string mesto, string drzava, double cena, double popust, int broj_dana, int ukupno_mesta, DateTime datum)
        {
            ID = iD;
            this.mesto = mesto;
            this.drzava = drzava;
            this.cena = cena;
            this.popust = popust;
            this.broj_dana = broj_dana;
            this.ukupno_mesta = ukupno_mesta;
            this.datum = datum;
        }

        public int ID1 { get => ID; set => ID = value; }
        public string Mesto { get => mesto; set => mesto = value; }
        public string Država { get => drzava; set => drzava = value; }
        public double Cena { get => cena; set => cena = value; }
        public double Popust { get => popust; set => popust = value; }
        public int Broj_dana { get => broj_dana; set => broj_dana = value; }
        public int Ukupno_mesta { get => ukupno_mesta; set => ukupno_mesta = value; }
        public DateTime Datum { get => datum; set => datum = value; }

        public override string ToString()
        {
            return " ID " + ID + " Mesto " + Mesto + " Drzava " + drzava + " Cena " + cena + "€  Popust " + popust + "%  Broj_dana " + broj_dana + " Ukupno Mesta"
                + Ukupno_mesta + " Datum " + Datum.ToString("dd-MM-yyyy");
        }
    }
}
