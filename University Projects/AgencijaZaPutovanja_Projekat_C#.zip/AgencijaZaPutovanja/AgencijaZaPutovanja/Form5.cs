﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace AgencijaZaPutovanja
{
    public partial class Form5 : Form
    {
        List<Rezervacija>listaRezervacija=new List<Rezervacija>();
        List<Izlet>ListaIzleta=new List<Izlet>();
        List<string>ListaID=new List<string>();
        List<string>listaA=new List<string>();
        List<string> tempLista = new List<string>();
        Form7 form7;
        Form1 form1;
        string bezId;
        public ID_REZ x = new ID_REZ(0);
        public int vrednost_id=0,vr=0;
        int curIndex;
        public Form5()
        {
            InitializeComponent();
            DeserijalizacijauListu();
        }
        //metode
        public void uzmiId(int Id=0)
        {
             vrednost_id = Id;
        }
        public int X
        {
            get { return x.ID1; }
        }
        public void izbacivanjeId()
        {
            foreach (string s in tempLista)
            {
                bezId = s.Remove(0, 29);
                listaA.Add(bezId); // Dodajte u privremenu listu
                //MessageBox.Show(s);
            }
            lbRezervacije.DataSource = null;
            lbRezervacije.DataSource = listaA;
        }
        public void DeserijalizacijauListu()
        {
            try
            {
                if (File.Exists("rezervacije.bin"))
                {
                    using (FileStream fajl = new FileStream(("rezervacije.bin"), FileMode.Open, FileAccess.Read))
                    {
                        BinaryFormatter binform = new BinaryFormatter();
                        while (fajl.Position < fajl.Length)
                        {
                            object objekat = binform.Deserialize(fajl);
                            Rezervacija rez= (Rezervacija)objekat;
                            listaRezervacija.Add(rez);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void serijalizujFajl()
        {
            try
            {
                if (File.Exists("rezervacije.bin"))
                {
                    using (FileStream fajl = new FileStream(("rezervacije.bin"), FileMode.Create, FileAccess.Write))
                    {
                        BinaryFormatter binform = new BinaryFormatter();
                        foreach(Rezervacija rez in listaRezervacija)
                        {
                            binform.Serialize(fajl, rez);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void proveraBrisi()
        {
            if(curIndex !=-1)
            {
                button4.Enabled = true;
            }
            else button4.Enabled = false;
        }
        public void PrikazNaListBoxu()
        {
            int id;
            foreach(Rezervacija rez in listaRezervacija)
            {
                id = rez.ID_korisnika1;
                //MessageBox.Show("ID iz fajla rezervacije" + id.ToString());
                //MessageBox.Show("ID iz fajla korisnik" + vrednost_id.ToString());
                if (rez.ID_korisnika1 == vrednost_id)
                {
                    tempLista.Add(rez.ToString());
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (form1 == null || form1.IsDisposed)
            {
                form1 = new Form1();
                form1.FormClosed += Form1_FormClosed;
            }
            form1.Show();
            this.Hide();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            form1 = null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (form7 == null || form7.IsDisposed)
            {
                form7= new Form7();
                form7.FormClosed += Form1_FormClosed;
            }
            form7.Show();
            this.Hide();
        }

        private void Form7_FormClosed(object sender, FormClosedEventArgs e)
        {
            form7 = null;
        }

        private void button4_Click(object sender, EventArgs e)
        {

                if (curIndex != -1 && curIndex < listaRezervacija.Count)
                {
                    listaRezervacija.RemoveAt(curIndex);
                    lbRezervacije.DataSource = null;
                    lbRezervacije.DataSource = listaRezervacija;
                    serijalizujFajl();
                    MessageBox.Show("Uspesno ste izbrisali rezervaciju");
                }
           

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            proveraBrisi();
        }

        private void lbRezervacije_SelectedIndexChanged(object sender, EventArgs e)
        {
            curIndex = lbRezervacije.SelectedIndex;
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            form1=new Form1();
            vr = form1.Id_usera;
            form7=new Form7();
            form7.NasId(vrednost_id);
            PrikazNaListBoxu();
            izbacivanjeId();
            timer1.Start();
            timer1.Enabled = true;
            lbRezervacije.SelectedIndex = -1;
        }
    }
}
