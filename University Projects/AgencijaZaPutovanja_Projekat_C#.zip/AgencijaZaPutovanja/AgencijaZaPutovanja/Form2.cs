﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgencijaZaPutovanja
{
    public partial class Form2 : Form
    {
        // Globalna prom tipa TextBox sluzi da znamo koji TextBox da Setujemo/Resetujemo
        TextBox trenutni_izabrani;
        Form1 form1;
        Form4 form4;
        Korisnik nalog;
        int flag = 0;
        List<string> ListaZaSifre = new List<string>();
        int ID;
        public Form2(Form1 form1)
        {
            InitializeComponent();
            // ovako izbegavamo overflow
            this.form1 = form1;
            timer1.Start();
            timer1.Enabled = true;
            PrikaziSkriveniTextBox();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // Postavljamo fokus na Prvi tekstbox
            this.ActiveControl = txtIme;
            UbacivanjeSifriUlistu();
        }
        public void PrikaziSkriveniTextBox(bool prikazi=false)
        {
            txtVrstaNaloga.Visible = prikazi;
        }
        public void ResetTextBoxa(TextBox t)
        {
            t.BackColor = Color.FromArgb(255, 192, 192);
            t.BorderStyle = BorderStyle.None;
            if (t == txtIme)
            {
                t.Text = "Ime";
            }
            else if (t == txtPrezime)
            {
                t.Text = "Prezime";
            }
            else if (t == txtUsername)
            {
                t.Text = "Korisnicko Ime";
            }
            else if (t == txtSifra)
            {
                t.Text = "Sifra";
                // Ukida mi se "Sifrovana" poruka na tekstboxu Sifra
                t.PasswordChar = '\0';
            }
            else if(t == txtPotvrdaSifre)
            {
                t.Text = "Potvrda Sifre";
                // Ukida mi se "Sifrovana" poruka na tekstboxu PotvrdaSifre
                t.PasswordChar = '\0';
            }
            else
            {
                t.Text = "Vrsta naloga";
            }    
        }
        public void SetovanjeTextBoxa(TextBox t)
        {

            t.BackColor = Color.White;
            t.BorderStyle = BorderStyle.Fixed3D;
            t.Text = "";
        }
        public void ProveraTextBoxa()
        {
            if (txtUsername.Text == "Korisnicko Ime" || string.IsNullOrEmpty(txtUsername.Text)) lblUsername.Text = "";
            if (txtSifra.Text != "Sifra" || string.IsNullOrEmpty(txtSifra.Text)) lblSifra.Text = "";
        }
   
        public bool ProveraUsernameIliSifre(TextBox t,Label l)
        {
            char[] nizKaraktera = t.Text.ToCharArray();
            int FlagVelikoSlovo = 0,
            FlagSpecijalanZnak = 0;
            if (string.IsNullOrEmpty(t.Text) || t.Text == "Korisnicko Ime" || t.Text == "Sifra")
            {
                l.Text = "";
                return true;
            }
            if (char.IsDigit(nizKaraktera[0]))
            {
                l.Text = ("Ne moze stajati broj na pocetku ");
                return false;
            }
            else if (char.IsPunctuation(nizKaraktera[0]) || char.IsWhiteSpace(nizKaraktera[0]) || char.IsSymbol(nizKaraktera[0]))
            {
                l.Text = ("Ne moze stajati specijalan znak na pocetku ");
                return false;
            }
            foreach (char c in t.Text)
            {

                //65 - 106 velika slova od A-Z
                if ((int)c >= 65 && (int)c <= 90 && FlagVelikoSlovo == 0)
                {
                    FlagVelikoSlovo = 1;
                }
                // znaci interpunkcije i slova
                if ((int)c >= 33 && (int)c <= 64 && FlagSpecijalanZnak == 0)
                {
                    FlagSpecijalanZnak = 1;
                }
            }
            if (FlagVelikoSlovo == 0)
            {
                 l.Text = ("Mora imati barem jedno veliko slovo");
                return false;
            }
            else if (FlagVelikoSlovo == 1 && FlagSpecijalanZnak == 0)
            {
                l.Text = ("Mora imati barem jedan znak interpunkcije " + '\n' + " ili barem jedan broj");
                return false;
            }
            else
            {
                    l.Text = "";
                return true;
            }
        }
        public bool PotvrdaSifre()
        {
            if(txtPotvrdaSifre.Text!="Potvrda Sifre" && !string.IsNullOrEmpty(txtPotvrdaSifre.Text))
            {
                if (txtSifra.Text == txtPotvrdaSifre.Text)
                {
                    lblPotvrdaSifre.Text = "";
                    return true;
                }
                else
                {
                    lblPotvrdaSifre.Text = " Niste napisali istu sifru ";
                    return false;
                }
            }
            else { return false; }
        }
        public bool DodajUFajl()
        {
            // bez nullempty provere ce nam proveravati i prazne znake i izbacivace gresku da je Index out of array
            if (!string.IsNullOrEmpty(txtUsername.Text) && txtUsername.Text != "Korisnicko Ime" && ProveraUsernameIliSifre(txtUsername, lblUsername))
                if (!string.IsNullOrEmpty(txtSifra.Text) && txtSifra.Text != "Sifra" && ProveravanjeSifriIzListe())
                    if (!string.IsNullOrEmpty(txtIme.Text) && txtIme.Text != "Ime")
                        if (!string.IsNullOrEmpty(txtPrezime.Text) && txtPrezime.Text != "Prezime")
                            if (PotvrdaSifre()) return true;
                            else return false;
                        else return false;
                    else return false;
                else return false;
            else  return false;

        }
        public bool UpisUKlasu()
        {
            string Vrsta_Naloga = "";
            if (DodajUFajl() == true)
            {
                ID = CitanjeIdIzFajla();
                if (!txtVrstaNaloga.Visible)
                {
                    Vrsta_Naloga = "Klijentska";
                }
                else Vrsta_Naloga = txtVrstaNaloga.Text;
                nalog = new Korisnik(ID,txtIme.Text, txtPrezime.Text, txtUsername.Text, txtSifra.Text,Vrsta_Naloga);
                ID++;
                UpisivanjeIdUFajl(ID);
                return true;
            }
            else return false;
        }
        public void SerijalizacijaObjekta()
        {
            // Binarna serijalizacija naseg objeka nalog
            try
            {
               // ako ne postoji kreiramo fajl nalog.bin
               if (!File.Exists("nalog.bin")) File.Create("nalog.bin").Close();
               // otvaramo ga u append rezimu
               FileStream fajl = new FileStream("nalog.bin", FileMode.Append);
               BinaryFormatter binform = new BinaryFormatter();
               binform.Serialize(fajl,nalog);
               fajl.Flush();
               fajl.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void UbacivanjeSifriUlistu()
        {
            try
            {
                if (File.Exists("nalog.bin"))
                {
                    FileStream fajl = new FileStream("nalog.bin", FileMode.Open, FileAccess.Read);
                    BinaryFormatter binform = new BinaryFormatter();
                    while (fajl.Position < fajl.Length)
                    {
                        object objekat = binform.Deserialize(fajl);
                        Korisnik nalog = (Korisnik)objekat;
                        ListaZaSifre.Add(nalog.Sifra1);
                    }
                    fajl.Close ();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        public bool ProveravanjeSifriIzListe()
        {
            if (ListaZaSifre.Count > 0)
            {
                if (ListaZaSifre.Contains(txtSifra.Text))
                {
                    lblSifra.Text = "Šifra već postoji!";
                    return false;
                }
                else
                {
                    return ProveraUsernameIliSifre(txtSifra, lblSifra);
                }
            }
            else
            {
                return ProveraUsernameIliSifre(txtSifra, lblSifra);
            }
        }

        public void CapsLock()
        {
            bool CapsLock= Control.IsKeyLocked(Keys.CapsLock);
            if (CapsLock)
            {
                lblCaps.Text = "Caps Lock ukljucen";
            }
            else
            {
                lblCaps.Text = "";
            }
        }
        private int CitanjeIdIzFajla()
        {
            if (File.Exists("Id.txt"))
            {
                using (StreamReader citanje = new StreamReader("Id.txt"))
                {
                    string line = citanje.ReadLine();
                    citanje.Close();
                    return int.Parse(line);
                }
            }
            else
            {
                return 1; // Ako fajl ne postoji, počinjemo od ID 0
            }
        }

        private void UpisivanjeIdUFajl(int id)
        {
            using (StreamWriter upisivanje = new StreamWriter("Id.txt", false))
            {
                upisivanje.Write(id.ToString());
                upisivanje.Close();
            }
        }

     

        //Kraj metoda

        //====================================================//
        private void txtIme_Click(object sender, EventArgs e)
        {
            SetovanjeTextBoxa(txtIme);
            trenutni_izabrani = txtIme;
        }

        private void txtPrezime_Click(object sender, EventArgs e)
        {
            SetovanjeTextBoxa(txtPrezime);
            trenutni_izabrani = txtPrezime;
        }
        private void txtUsername_Click(object sender, EventArgs e)
        {
            SetovanjeTextBoxa(txtUsername);
            trenutni_izabrani = txtUsername;
        }
        private void txtSifra_Click(object sender, EventArgs e)
        {
            SetovanjeTextBoxa(txtSifra);
            trenutni_izabrani = txtSifra;
            txtSifra.PasswordChar = '*';
        }
        private void txtPotvrdaSifre_Click(object sender, EventArgs e)
        {
            SetovanjeTextBoxa(txtPotvrdaSifre);
            trenutni_izabrani = txtPotvrdaSifre;
            txtPotvrdaSifre.PasswordChar= '*';
        }
        private void txtVrstaNaloga_Click(object sender, EventArgs e)
        {
            SetovanjeTextBoxa(txtVrstaNaloga);
            trenutni_izabrani = txtVrstaNaloga;
        }
        //============================================================//
        private void panel1_Click(object sender, EventArgs e)
        {
            // resetuje textBox kada kliknemo na tabControl
            if (trenutni_izabrani != null)
            ResetTextBoxa(trenutni_izabrani);
        }

        private void Form2_Click(object sender, EventArgs e)
        {
            // resetuje textBox kada kliknemo na Panel
            if(trenutni_izabrani!=null)
            ResetTextBoxa(trenutni_izabrani);
        }

        private void panel2_MouseEnter(object sender, EventArgs e)
        { 
    
            if(flag==0)
            {
                panel2.Cursor = Cursors.Hand; 
            }
            else
            {
                panel2.Cursor= Cursors.No;
            }
         
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            CapsLock();
            ProveraTextBoxa();
            if (checkBox1.Checked == true)
            {
                txtSifra.PasswordChar = '\0';
                txtPotvrdaSifre.PasswordChar = '\0';
            }
            else if (txtPotvrdaSifre.Text != "Potvrda Sifre" && txtSifra.Text != "Sifra" && checkBox1.Checked == false)
            {
                txtSifra.PasswordChar = '*';
                txtPotvrdaSifre.PasswordChar = '*';
            }
            if (!DodajUFajl())
            {
                if (flag == 0)
                {
                    button1.Text = "Popunite-Sva-Polja";
                    button1.ForeColor = Color.Black;
                    button1.BackColor = Color.Red;
                    button1.Enabled = false;
                    _ = button1.Font.Bold;
                    flag = 1;
                }
            }
            else
            {
                if (flag == 1)
                {
                    button1.Text = "Klikni-za-kreiranje";
                    button1.ForeColor = Color.Black;
                    button1.BackColor = Color.Green;
                    button1.Enabled = true;
                    // - = discard operater koji nam dozvoljava da pozovemo metodu
                    // ali da njenu vrednost kuliramo(true u ovom slucaju),vec samo zelimo da 
                    // manipulisemo objektom
                    _ = button1.Font.Bold;
                    flag = 0;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // ako je svaki uslov ispunjen pravimo instancu i upisujemo podatke sa tekstboxa
            if(DodajUFajl())
            {
                // pozivamo metodu za upisivanje u klasu podataka sa forme
                if (UpisUKlasu())
                {
                    SerijalizacijaObjekta();
                    MessageBox.Show("Uspesno kreiran Nalog");
                }
                    
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void txtVrstaNaloga_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtVrstaNaloga_VisibleChanged(object sender, EventArgs e)
        {

        }
    }
}
