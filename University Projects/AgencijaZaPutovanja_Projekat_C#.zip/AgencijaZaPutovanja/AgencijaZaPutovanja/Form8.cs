﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace AgencijaZaPutovanja
{
    public partial class Form8 : Form
    {
        Form4 form4= new Form4();
        List<string> lista = new List<string>();
        Izlet izlet;
        int Id_f8;
        DateTime datum;
        public Form8()
        {
            InitializeComponent();
            timer1.Start();
            timer1.Enabled = true;
        }
        // metode
        public bool ProveraTextBoxova()
        {
            if (!string.IsNullOrEmpty(txtMesto.Text) && !string.IsNullOrEmpty(txtDrzava.Text) && !string.IsNullOrEmpty(txtCena.Text) && !string.IsNullOrEmpty(txtPopust.Text) &&
                !string.IsNullOrEmpty(txtBrojDana.Text) && !string.IsNullOrEmpty(txtUkupnoMesta.Text))
                return true;
            else {
                lblMesto.Text = "";
                lblDrzava.Text = "";
                lblCena.Text = "";
                lblPopust.Text = "";
                lblBrojDana.Text = "";
                lblUkupnoMesta.Text = "";
                return false;
            }
        }
        public bool String(TextBox t, Label l)
        {
            char[] nizKaraktera = t.Text.ToCharArray();
            if (char.IsDigit(nizKaraktera[0]))
            {
                l.Text = ("Ne moze stajati broj na pocetku ");
                return false;
            }
            else if (char.IsPunctuation(nizKaraktera[0]) || char.IsWhiteSpace(nizKaraktera[0]) || char.IsSymbol(nizKaraktera[0]))
            {
                l.Text = ("Ne moze stajati specijalan znak na pocetku ");
                return false;
            }
            else
            {
                l.Text = "";
                return true;
            }
        }
        public bool proveraStringova()
        {
            if (String(txtMesto, lblMesto) && String(txtDrzava, lblDrzava)) return true;
            else return false;
        }
        public bool NeMozeBitiBroj()
        {
            bool validacija = true;
            if (double.TryParse(txtCena.Text, out double rez))
            {
                if (rez < 0)
                {
                    lblCena.Text = "Vrednost ne sme biti negativna!";
                    validacija = false;
                }
                else lblCena.Text = "";
            }
            else
            {
                lblCena.Text = "Unos mora biti broj!";
                validacija = false;
            }

            if (double.TryParse(txtPopust.Text, out double r))
            {
                if (r < 0)
                {
                    lblPopust.Text = "Vrednost ne sme biti negativna!";
                    validacija = false;
                }
                else lblPopust.Text = "";
            }
            else
            {
                lblPopust.Text = "Unos mora biti broj!";
                validacija = false;
            }

            if (int.TryParse(txtBrojDana.Text, out int re))
            {
                if (re < 0)
                {
                    lblBrojDana.Text = "Vrednost ne sme biti negativna!";
                    validacija = false;
                }
                else lblBrojDana.Text = "";
            }
            else
            {
                lblBrojDana.Text = "Unos mora biti broj!";
                validacija = false;
            }

            if (int.TryParse(txtUkupnoMesta.Text, out int rezz))
            {
                if (rezz < 0)
                {
                    lblUkupnoMesta.Text = "Vrednost ne sme biti negativna!";
                    validacija = false;
                }
                else lblUkupnoMesta.Text = "";
            }
            else
            {
                lblUkupnoMesta.Text = "Unos mora biti broj!";
                validacija = false;
            }
            datum = dateTimePicker1.Value;
            if (datum.Date > DateTime.Today)
            {
                lblDatum.Text = "";
                validacija = true;
            }
            else
            {
                lblDatum.Text = "Pogresan datum";
                validacija = false;
            }

            return validacija;

        }
        private int CitanjeIdIzFajla()
        {
            if (File.Exists("Id.txt"))
            {
                using (StreamReader citanje = new StreamReader("Id.txt"))
                {
                    string line = citanje.ReadLine();
                    citanje.Close();
                    return int.Parse(line);
                }
            }
            else
            {
                return 1; // Ako fajl ne postoji, počinjemo od ID 0
            }
        }

        private void UpisivanjeIdUFajl(int id)
        {
            using (StreamWriter upisivanje = new StreamWriter("Id.txt", false))
            {
                upisivanje.Write(id.ToString());
                upisivanje.Close();
            }
        }
        public void napraviIzlet()
        {
            Id_f8=CitanjeIdIzFajla();
            izlet = new Izlet(Id_f8,txtMesto.Text,txtDrzava.Text,Double.Parse(txtCena.Text),Double.Parse(txtPopust.Text),int.Parse(txtBrojDana.Text),int.Parse(txtUkupnoMesta.Text),datum);
            Id_f8++;
            UpisivanjeIdUFajl(Id_f8);
        }
        public void DodajUlistu()
        {
            napraviIzlet();
            lista.Add(izlet.ToString());
        }
        public void upisiUListuFormeAdmin()
        {
            DodajUlistu();
            form4.LblIzleti.DataSource = null;
            form4.LblIzleti.DataSource = lista;
        }
        public void SerijalizujObjekat()
        {
            try
            {
                if(File.Exists("IZLETI.bin"))
                {
                    using (FileStream fajl = new FileStream(("IZLETI.bin"), FileMode.Append))
                    {
                        BinaryFormatter binform = new BinaryFormatter();
                        // zovemo metodu da kreira objekat koji serijalizujemo posle
                        napraviIzlet();
                        binform.Serialize(fajl, izlet);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if(form4==null || form4.IsDisposed)
            {
                form4=new Form4();
                form4.FormClosed += Form4_FormClosed;
            }
            form4.Show();
            this.Hide();
        }

        private void Form4_FormClosed(object sender, FormClosedEventArgs e)
        {
            form4= null;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (ProveraTextBoxova())
            {
                if (proveraStringova() && NeMozeBitiBroj())
                {
                    button1.Enabled = true;
                    button3.Enabled = true;
                }
                else
                {
                    button1.Enabled = false;
                    button3.Enabled = false;
                }
            }
            else
            {
                button1.Enabled = false;
                button3.Enabled = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            upisiUListuFormeAdmin();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            SerijalizujObjekat();
        }
    }
}
