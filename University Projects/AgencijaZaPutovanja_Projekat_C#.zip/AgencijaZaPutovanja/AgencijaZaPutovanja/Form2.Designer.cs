﻿namespace AgencijaZaPutovanja
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtVrstaNaloga = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.lblCaps = new System.Windows.Forms.Label();
            this.lblPotvrdaSifre = new System.Windows.Forms.Label();
            this.lblSifra = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.lblUsername = new System.Windows.Forms.Label();
            this.txtPotvrdaSifre = new System.Windows.Forms.TextBox();
            this.txtPrezime = new System.Windows.Forms.TextBox();
            this.txtIme = new System.Windows.Forms.TextBox();
            this.txtSifra = new System.Windows.Forms.TextBox();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.txtVrstaNaloga);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.lblCaps);
            this.panel1.Controls.Add(this.lblPotvrdaSifre);
            this.panel1.Controls.Add(this.lblSifra);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.lblUsername);
            this.panel1.Controls.Add(this.txtPotvrdaSifre);
            this.panel1.Controls.Add(this.txtPrezime);
            this.panel1.Controls.Add(this.txtIme);
            this.panel1.Controls.Add(this.txtSifra);
            this.panel1.Controls.Add(this.txtUsername);
            this.panel1.Location = new System.Drawing.Point(1, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(421, 584);
            this.panel1.TabIndex = 0;
            this.panel1.Click += new System.EventHandler(this.panel1_Click);
            // 
            // txtVrstaNaloga
            // 
            this.txtVrstaNaloga.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtVrstaNaloga.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.txtVrstaNaloga.ForeColor = System.Drawing.Color.DimGray;
            this.txtVrstaNaloga.Location = new System.Drawing.Point(67, 447);
            this.txtVrstaNaloga.Multiline = true;
            this.txtVrstaNaloga.Name = "txtVrstaNaloga";
            this.txtVrstaNaloga.Size = new System.Drawing.Size(224, 29);
            this.txtVrstaNaloga.TabIndex = 14;
            this.txtVrstaNaloga.Text = "Vrsta naloga";
            this.txtVrstaNaloga.Click += new System.EventHandler(this.txtVrstaNaloga_Click);
            this.txtVrstaNaloga.VisibleChanged += new System.EventHandler(this.txtVrstaNaloga_VisibleChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(312, 279);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(106, 21);
            this.checkBox1.TabIndex = 13;
            this.checkBox1.Text = "Prikazi Sifru";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // lblCaps
            // 
            this.lblCaps.AutoSize = true;
            this.lblCaps.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCaps.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblCaps.Location = new System.Drawing.Point(80, 492);
            this.lblCaps.Name = "lblCaps";
            this.lblCaps.Size = new System.Drawing.Size(85, 24);
            this.lblCaps.TabIndex = 12;
            this.lblCaps.Text = "LblCaps";
            // 
            // lblPotvrdaSifre
            // 
            this.lblPotvrdaSifre.AutoSize = true;
            this.lblPotvrdaSifre.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.lblPotvrdaSifre.ForeColor = System.Drawing.Color.Red;
            this.lblPotvrdaSifre.Location = new System.Drawing.Point(31, 412);
            this.lblPotvrdaSifre.Name = "lblPotvrdaSifre";
            this.lblPotvrdaSifre.Size = new System.Drawing.Size(0, 19);
            this.lblPotvrdaSifre.TabIndex = 10;
            // 
            // lblSifra
            // 
            this.lblSifra.AutoSize = true;
            this.lblSifra.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.lblSifra.ForeColor = System.Drawing.Color.Red;
            this.lblSifra.Location = new System.Drawing.Point(31, 318);
            this.lblSifra.Name = "lblSifra";
            this.lblSifra.Size = new System.Drawing.Size(0, 19);
            this.lblSifra.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Yu Gothic", 15.75F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(104, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 27);
            this.label1.TabIndex = 8;
            this.label1.Text = "Napravi nalog ";
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.Controls.Add(this.button1);
            this.panel2.Location = new System.Drawing.Point(69, 519);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(194, 51);
            this.panel2.TabIndex = 7;
            this.panel2.MouseEnter += new System.EventHandler(this.panel2_MouseEnter);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(15, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(165, 45);
            this.button1.TabIndex = 5;
            this.button1.Text = "Popunite-Sva-Polja";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsername.ForeColor = System.Drawing.Color.Red;
            this.lblUsername.Location = new System.Drawing.Point(31, 228);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(0, 19);
            this.lblUsername.TabIndex = 6;
            // 
            // txtPotvrdaSifre
            // 
            this.txtPotvrdaSifre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtPotvrdaSifre.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.txtPotvrdaSifre.ForeColor = System.Drawing.Color.DimGray;
            this.txtPotvrdaSifre.Location = new System.Drawing.Point(67, 349);
            this.txtPotvrdaSifre.Multiline = true;
            this.txtPotvrdaSifre.Name = "txtPotvrdaSifre";
            this.txtPotvrdaSifre.Size = new System.Drawing.Size(224, 30);
            this.txtPotvrdaSifre.TabIndex = 4;
            this.txtPotvrdaSifre.Text = "Potvrda Sifre";
            this.txtPotvrdaSifre.Click += new System.EventHandler(this.txtPotvrdaSifre_Click);
            // 
            // txtPrezime
            // 
            this.txtPrezime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtPrezime.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.txtPrezime.ForeColor = System.Drawing.Color.DimGray;
            this.txtPrezime.Location = new System.Drawing.Point(67, 124);
            this.txtPrezime.Multiline = true;
            this.txtPrezime.Name = "txtPrezime";
            this.txtPrezime.Size = new System.Drawing.Size(224, 27);
            this.txtPrezime.TabIndex = 3;
            this.txtPrezime.Text = "Prezime";
            this.txtPrezime.Click += new System.EventHandler(this.txtPrezime_Click);
            // 
            // txtIme
            // 
            this.txtIme.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtIme.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.txtIme.ForeColor = System.Drawing.Color.DimGray;
            this.txtIme.Location = new System.Drawing.Point(69, 52);
            this.txtIme.Multiline = true;
            this.txtIme.Name = "txtIme";
            this.txtIme.Size = new System.Drawing.Size(224, 29);
            this.txtIme.TabIndex = 2;
            this.txtIme.Text = "Ime";
            this.txtIme.Click += new System.EventHandler(this.txtIme_Click);
            // 
            // txtSifra
            // 
            this.txtSifra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtSifra.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.txtSifra.ForeColor = System.Drawing.Color.DimGray;
            this.txtSifra.Location = new System.Drawing.Point(67, 270);
            this.txtSifra.Multiline = true;
            this.txtSifra.Name = "txtSifra";
            this.txtSifra.Size = new System.Drawing.Size(224, 30);
            this.txtSifra.TabIndex = 1;
            this.txtSifra.Text = "Sifra";
            this.txtSifra.Click += new System.EventHandler(this.txtSifra_Click);
            // 
            // txtUsername
            // 
            this.txtUsername.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtUsername.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.txtUsername.ForeColor = System.Drawing.Color.DimGray;
            this.txtUsername.Location = new System.Drawing.Point(67, 190);
            this.txtUsername.Multiline = true;
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(224, 32);
            this.txtUsername.TabIndex = 0;
            this.txtUsername.Text = "Korisnicko Ime";
            this.txtUsername.Click += new System.EventHandler(this.txtUsername_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 583);
            this.Controls.Add(this.panel1);
            this.Name = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.Click += new System.EventHandler(this.Form2_Click);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtSifra;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtPotvrdaSifre;
        private System.Windows.Forms.TextBox txtPrezime;
        private System.Windows.Forms.TextBox txtIme;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblSifra;
        private System.Windows.Forms.Label lblPotvrdaSifre;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblCaps;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox txtVrstaNaloga;
    }
}