import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import numpy as np

# Ucitavanje podataka
podaci = pd.read_csv('Housing.csv')


# Konvertovanje kategorickih kolona(Object kolona) koristeći One-Hot Encoding
X = pd.get_dummies(podaci[['area', 'bedrooms', 'bathrooms', 'stories', 'mainroad', 'guestroom', 'basement', 'hotwaterheating', 'airconditioning']])
y = podaci['price']

# Podela podataka na trening set i test set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Izbor i treniranje modela
model = LinearRegression()
model.fit(X_train, y_train)

# Predvidjanje cena za svaku godinu od 2024. do 2034.
Buduca_cena = []
years = range(2024, 2035)  # Godine za koje zelimo da predvidimo cene
for year in years:
    np.random.seed()  # Ne postavljanje seed-a kako bi generisali razlicite slyucajne brojeve
    area = np.random.randint(7000, 14001)
    bedrooms = np.random.randint(1, 5)
    bathrooms = np.random.randint(1, 5)
    stories = np.random.randint(1, 5)
    mainroad = np.random.randint(0, 2)
    guestroom = np.random.randint(0, 2)
    basement = np.random.randint(0, 2)
    hotwaterheating = np.random.randint(0, 2)
    airconditioning = np.random.randint(0, 2)


## Kreira se tabela (slicna DataTable iz c#) koja ima isti kostur
## kao i original dataset
    X_pred = pd.DataFrame({
        'area': [area],
        'bedrooms': [bedrooms],
        'bathrooms': [bathrooms],
        'stories': [stories],
        'mainroad': [mainroad],
        'guestroom': [guestroom],
        'basement': [basement],
        'hotwaterheating': [hotwaterheating],
        'airconditioning': [airconditioning]
    })

    # Konvertovanje kategorickih kolona u One-Hot Encoding
    X_pred = pd.get_dummies(X_pred)
    # Resavanje neslaganja u nazivima kolona
    izgubljene_kolone = set(X.columns) - set(X_pred.columns)
    for col in izgubljene_kolone:
        X_pred[col] = 0
    # Sortiranje kolona
    X_pred = X_pred[X.columns]

    # Predviđanje cena za trenutnu godinu
    bcena = model.predict(X_pred)
    Buduca_cena.append(bcena[0])

# Vizualizacija rezultata pomocu stubicastog dijagrama
plt.figure(figsize=(10, 6))
plt.bar(years, Buduca_cena, color='red', alpha=0.5)
plt.xlabel('Godina')
plt.ylabel('Cena nekretnine * 1 000 000(€)')
plt.title('Predviđene cene nekretnina za narednih 10 godina')
plt.show()