#include "Knn.h"
#include <cmath>
#include <limits>
#include <map>
#include <iostream>
#include "DataHandlers.h"

Knn::Knn(){

}
Knn::~Knn(){

}
void Knn:: FindKnearest(DataContainer * data){

}

void Knn::SetK(int newK){
  this->k=newK;
}
int Knn::Predict(){

}
double Knn::CalculateDistance(DataContainer * array_of_dot_1 ,DataContainer * array_of_dot_2){
     
    if(array_of_dot_1->GetNormalizedFeatureVectorSize () != array_of_dot_2->GetNormalizedFeatureVectorSize () ){
        cout << " Arrays of dots are incompatible " << endl;
        exit(1);
    }
    // Euclidian 
    double distance = 0.0;
        for(unsigned i = 0 ; i < array_of_dot_1->GetNormalizedFeatureVectorSize() ; i++ ){
            distance += pow(array_of_dot_1->GetNormalizedVector()->at(i) - array_of_dot_2->GetNormalizedVector()->at(i),2);
    }
    distance = sqrt(distance);
    return distance;
}
double Knn::ValidatePerformance(){

}
double Knn::TestPerformance(){

}
