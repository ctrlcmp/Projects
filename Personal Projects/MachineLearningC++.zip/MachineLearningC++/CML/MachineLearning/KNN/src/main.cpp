#include "Knn.h"
#include "DataHandlers.h"
#include <iostream>
using namespace std;




int main(){  
    DataContainer * data = new DataContainer();
    DataHandlers * handlers= new DataHandlers();
    
    handlers->ReadFeaturesVector("../../../MNIST/train-images.idx3-ubyte");
    handlers->ReadFeaturesLabel("../../../MNIST/train-labels.idx1-ubyte");
    handlers->SplitData();
    handlers->CountClasses();

    Knn *knearest = new Knn();
    double performance = 0.0;
    double best_perfromance = 0.0;
    int best_k = 0;
    // Training
    for(int i  = 1 ; i <= 4; i++){
      cout << " Usao u ovaj for " << endl;
       if(i == 1){
         knearest->SetK(i);
         performance = knearest->TestPerformance();
         cout << "prosao"; 
         best_perfromance=performance; 
         cout << "Poslednji deo ifa " << endl << " Trenutni najbolji performans je " << best_perfromance << endl;
       }
       else{
      cout << "usao u else " << endl << " Trenutni najbolji performans je " << best_perfromance << endl;
        knearest->SetK(i);
        performance = knearest->TestPerformance();
         if(performance > best_perfromance){
            best_perfromance=performance;
            best_k=i;
         }
       }
    }

    //Validating
    knearest->SetK(best_k);
    knearest->ValidatePerformance();

    delete data;
    delete handlers;
    return 0;
}