#ifndef __KNNH
#define __KNNH

#include <vector>
#include "DataContainer.h"
#include "LearningData.h"

class Knn : public LearningData{
  private:
    int k;
    std::vector<DataContainer *> *neighbours;

  public:
    Knn();
    ~Knn();
    void FindKnearest(DataContainer *);
    void SetK(int);
    int Predict();
    double CalculateDistance(DataContainer *,DataContainer *);
    double ValidatePerformance();
    double TestPerformance();
};

#endif // __KNNH

