#include "Kmeans.h"



Kmeans::Kmeans(int k){
    num_clusters = k;
    clusters     = new std::vector<cluster_t *>;
    used_indexes = new std::unordered_set<int>;
}
void Kmeans::InitClusters(){
     for(int i = 0 ; i < num_clusters; i++)
     {
        int index = (rand() % training_data->size());
        // This is used for recalculation of clusters!
        while(used_indexes->find(index) != used_indexes->end())
        {
            index = (rand() % training_data->size());  
        }
        //Defining cluster using random partition of training data vector
        cluster_t * cluster = new cluster_t(training_data->at(index));
        clusters->push_back(cluster);
     }
}
void Kmeans::InitClustersForEachClass(){
    std::unordered_set<int>classes_used;
    for(size_t i = 0; i < training_data->size(); i++){
        if(classes_used.find(training_data->at(i)->GetLabel()) == classes_used.end())
        {
            cluster_t *cluster = new cluster_t(training_data->at(i));
            clusters->push_back(cluster);
            classes_used.insert(training_data->at(i)->GetLabel());
            used_indexes->insert(i);
        }
    }
}
void Kmeans::Train(){
    int index = 0;
    while(used_indexes->size() < training_data->size())
    {
        while(used_indexes->find(index) != used_indexes->end())
        {
            index++;
        }
        double min_distance = DBL_MAX;
        int best_cluster = 0;
        for(size_t j  = 0 ; j < clusters->size();j++)
        {
            double current_distance = Distance(clusters->at(j)->centroid,training_data->at(index));
            if(current_distance < min_distance)
            {
                min_distance=current_distance;
                best_cluster = j;
            }
        }
        clusters->at(best_cluster)->AddToCluster(training_data->at(index));
        used_indexes->insert(index);
    }


}
double Kmeans::Distance(std::vector<double> * centroid,DataContainer  *data){
    // if(centroid->size() != data->GetFeatureVectorSize()){
    //    std::cout << " Arrays must have same numbers of dimensions" << std::endl;
    //    exit(1);
    // }
    double distance = 0.0;
    for(size_t i = 0 ; i < centroid->size();i++){
         distance += pow(centroid->at(i) - data->GetVector()->at(i),2);
    }
    distance = sqrt(distance);
    return distance;
}
double Kmeans::Validate(){
    double correction_rate=0.0;
    for(auto data : *(validation_data) )
    {
        double min_distance = DBL_MAX;
        int best_cluster = 0;
        for(size_t j  = 0 ; j < clusters->size();j++)
        {
            double current_distance = Distance(clusters->at(j)->centroid,data);
            if(current_distance < min_distance)
            {
                min_distance=current_distance;
                best_cluster=j;
            }
        }
        if(data->GetLabel() == clusters->at(best_cluster)->most_frequent){
            correction_rate++;
        }
    }
    return 100.0 * correction_rate / (double)validation_data->size();
   

}
double Kmeans::Test(){
    double correction_rate=0.0;
    for(auto data : *(test_data) )
    {
        double min_distance = DBL_MAX;
        int best_cluster = 0;
        for(size_t j  = 0 ; j < clusters->size();j++)
        {
            double current_distance = Distance(clusters->at(j)->centroid,data);
            if(current_distance < min_distance)
            {
                min_distance=current_distance;
                best_cluster=j;
            }
        }
        if(data->GetLabel() == clusters->at(best_cluster)->most_frequent){
            correction_rate++;
        }
    }
    return 100.0 * correction_rate / (double)test_data->size();
   

}