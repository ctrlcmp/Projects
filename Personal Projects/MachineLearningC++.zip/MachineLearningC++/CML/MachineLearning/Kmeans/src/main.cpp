#include "Kmeans.h"
#include "DataHandlers.h"
#include  <omp.h>
using namespace std;


int main(){

    DataHandlers * handler = new DataHandlers(); 
    handler->ReadFeaturesVector("../../../MNIST/train-images.idx3-ubyte");
    handler->ReadFeaturesLabel("../../../MNIST/train-labels.idx1-ubyte");
    handler->SplitData();
    handler->CountClasses();
    double                              performance = 0.0;
    int                                 best_k = 0;
    
    //double                              best_performance = 0.0;
    // int                                 TenPercent =  handler->GetTrainingData()->size() *0.1;
    // vector<DataContainer*>              *training_data= handler-> GetTrainingData();
    // vector<DataContainer*>              *test_data= handler-> GetTestData();
    // vector<DataContainer*>              *validation_data= handler-> GetValidationData();

    // #pragma omp parallel for shared(best_performance, best_k) private(performance)
    // for(int i = handler->GetNumberOfClasses() ; i < TenPercent; i++)
    // {
    //     performance = 0.0;
    //     Kmeans *kmeans= new Kmeans(i);
    //     kmeans->SetTrainingData(training_data);
    //     kmeans->SetTestData(test_data);
    //     kmeans->SetValidationData(validation_data);
    //     kmeans->InitClusters();
    //     kmeans->Train();
    //     performance = kmeans->Validate();
    //     #pragma omp critical
    //     {
    //         cout << "Current performance at " << i << " is : " << performance << endl;
    //         if(performance > best_performance){
    //             best_performance=performance;
    //             best_k = i;
    //         }
    //     }
    //     delete kmeans;
    // }

    /////////////////////// DISCLAIMER //////////////////////////////////
        //  So after 380-ish its all the same performance of kmeans // 
        //  Current performance at 42 is : 75.7333                  //
        //  Current performance at 43 is : 77.5667                  //
        //  Current performance at 44 is : 75.4333                  //
        //  Current performance at 386 is : 90.8667                 //
        //  Current performance at 760 is : 91.9667                 //
        //  Current performance at 1134 is : 93.7                  //
    ////////////////////////////////////////////////////////////////////
    best_k=385;
    Kmeans *kmeans= new Kmeans(best_k);
    kmeans->SetTrainingData(handler->GetTrainingData());
    kmeans->SetTestData(handler->GetTestData());
    kmeans->SetValidationData(handler->GetValidationData());
    kmeans->InitClusters();
    performance=kmeans->Test();
    cout << "Final performance at " << best_k << " is : " << performance << endl;


    delete kmeans;
    return 0;
}