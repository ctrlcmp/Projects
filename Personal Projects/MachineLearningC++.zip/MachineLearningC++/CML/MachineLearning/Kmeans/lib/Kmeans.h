#ifndef __KMEANSH
#define __KMEANSH

#include                            "DataContainer.h"
#include                            "LearningData.h"
#include                            <map>
#include                            <unordered_set>
#include                            <cfloat>
#include                            <cmath>

typedef struct cluster{


     std::vector<double>          * centroid;
     std::vector<DataContainer*>  * Cluster;
     std::map<int,int>              class_counts;
     int                            most_frequent;
   public:

    cluster(DataContainer * data){
        Cluster  =  new std::vector<DataContainer*>;
        centroid =  new std::vector<double>;
        for(auto value  : *(data->GetVector())){
            centroid->push_back(value);
        }
        Cluster->push_back(data);
        class_counts[data->GetLabel()]=1;
        most_frequent= data->GetLabel();   
    }
    void AddToCluster(DataContainer * data){
        int previous_size = Cluster->size();
        Cluster->push_back(data);
        //Recalculation of all dots in Centroid using Incremental Mean Calculation,instead we could iterate and add all newDots with dots and subtract with newsize
        for(size_t i = 0 ; i < centroid->size(); i++){
            double value = centroid->at(i);
            value *= previous_size;
            value += data->GetVector()->at(i);
            value /= (double)Cluster->size();
            centroid->at(i)=value;
        }
       if(class_counts.find(data->GetLabel()) == class_counts.end()){
            class_counts[data->GetLabel()]=1;
       }
       else class_counts[data->GetLabel()]++;
       SetMostFrequentClass();
    }
    void SetMostFrequentClass(){
        int best_class;
        int max=INT_MIN;
        for(auto kv:class_counts)
        {
            if(kv.second > max){
                max = kv.second;
                best_class = kv.first;
            }
        }
        most_frequent=best_class;
    }

}cluster_t;


class Kmeans : public LearningData{

    private:
     int                           num_clusters;
     std::vector<cluster_t*>     * clusters;
     std::unordered_set<int>     * used_indexes;  

    public:
     Kmeans(int k);
     void                        InitClusters();
     void                        InitClustersForEachClass();
     void                        Train();
     double                      Distance(std::vector<double> *,DataContainer  *);
     double                      Validate();
     double                      Test();
    
};





#endif //__KMEANSH