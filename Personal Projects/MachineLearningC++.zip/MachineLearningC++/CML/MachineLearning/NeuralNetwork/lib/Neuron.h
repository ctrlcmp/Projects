#ifndef __NEURONH
#define __NEURONH

#include <cmath>
#include <vector>
class Neuron{
   public:
       std::vector<double>         weights;  
       double                      delta;
       double                      output;
       Neuron(int,int);
       ~Neuron();
       void                        InitializeWeights(int);

};


#endif