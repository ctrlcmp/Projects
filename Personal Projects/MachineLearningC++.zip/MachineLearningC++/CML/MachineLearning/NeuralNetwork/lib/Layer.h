#ifndef __LAYERH
#define __LAYERH

#include "Neuron.h"
#include <vector>

class Layer{
   public:
      int                        current_layer_size;
      std::vector<Neuron *>      neurons;
      std::vector<double>        layer_outputs;
                                 Layer(int,int);
                                 ~Layer();
      int                        GetSize();
      std::vector<double>        GetLayerOutput();
 
};



#endif