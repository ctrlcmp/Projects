#ifndef __NETWORKH
#define __NETWORKH

#include "DataContainer.h"
#include <vector>
#include "Neuron.h"
#include "Layer.h"
#include "LearningData.h"
#include  <algorithm>
class Network : public LearningData{
    private:
       std::vector<Layer *>          layers;
       double                        learning_rate;
       double                        test_performance;
    public:
      Network(std::vector<int>,int,int,double);
      ~Network();
      std::vector<double>           FeedForward(DataContainer *);
      double                        Activate(std::vector<double>,std::vector<double>);
      double                        Sigmoid(double);
      double                        SigmoidDerivative(double);//used in backprop
      void                          BackPropagation(DataContainer *);
      void                          UpdateWeights(DataContainer *data);
      void                          Train(int);//int num of interrations
      int                           Predict(DataContainer *data); // returns the index of max value in  output array
      double                        Test();
      void                          Validate();
    
};


#endif