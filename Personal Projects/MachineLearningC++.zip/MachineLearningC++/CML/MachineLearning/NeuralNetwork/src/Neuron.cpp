#include "Neuron.h"
#include <random>

double GenerateRandomNumber(double min,double max){
    double random = (double) rand()/ RAND_MAX;// Value bet 0.0 1.0
    return min+random * (max - min);
}
Neuron::Neuron(int previous_layer_size,int current_layer_size){
    InitializeWeights(previous_layer_size);

}
Neuron::~Neuron(){}
void Neuron:: InitializeWeights(int previous_layer_size)
{
  std::default_random_engine            generator;
  std::normal_distribution<double>      distribution(0.0,1.0);   
  for(int i = 0 ; i < previous_layer_size + 1; i++){
    weights.push_back(GenerateRandomNumber(-1.0,1.0));
  }
}