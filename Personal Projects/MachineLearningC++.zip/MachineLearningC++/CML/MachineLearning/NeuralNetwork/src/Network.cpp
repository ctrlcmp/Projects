#include "Network.h"
#include "Layer.h"
#include "DataHandlers.h"
#include <numeric>


Network::Network(std::vector<int>spec,int input_size,int number_of_classes,double learning_rate){
      
    for(size_t i = 0 ; i < spec.size (); i++)
   {
        if(i == 0){
            layers.push_back(new Layer(input_size,spec.at(i)));
        }else
        {
            layers.push_back(new Layer(layers.at(i-1)->neurons.size(),spec.at(i)));
        }
    }
    layers.push_back(new Layer(layers.at(layers.size()-1)->neurons.size(),number_of_classes));
    this->learning_rate=learning_rate;
}

Network::~Network(){}

std::vector<double>Network::FeedForward(DataContainer * data)
{
  std::vector<double>inputs = *data->GetNormalizedVector();
  for(size_t i = 0 ; i < layers.size() ; i++)
  {
     Layer * layer  =  layers[i];
     std::vector<double> vector_new_inputs;
     for(Neuron *n : layer->neurons)
     {
        double activation = this->Activate(n->weights,inputs);
        n->output = this->Sigmoid(activation);//Normalizing neuron value between 0.0 - > 1.0
        vector_new_inputs.push_back(n->output);
    }
    inputs = vector_new_inputs;
  }
  return inputs; // value of OUTPUT LAYER
}
void Network:: BackPropagation(DataContainer * data)
{
   size_t size  =  layers.size () - 1;
   for(int i = size ; i >= 0 ; i--)
   {
      Layer *layer= layers[i];
      std::vector<double> errors;
       

      if(i == size)
      {   
        for(size_t j = 0 ; j < layer->neurons.size();j++)
        {
           Neuron *n = layer->neurons[j];
           errors.push_back((double)data->GetClassVector()->at(j) - n->output);
        }
      }
      else {
        for(size_t j = 0 ; j < layer->neurons.size();j++)
        {
            double error = 0.0;
            for(Neuron * n : layers[i+1]->neurons)
            {
               error +=(n->weights.at(j) * n->delta);
            }
            errors.push_back(error);
        } 
      }
      // Delta : 
      for(size_t  j = 0 ; j < layer->neurons.size();j++)
      {
         Neuron *n = layer->neurons.at(j);
         // Delta is  Error within neurons used for bprop  
         n->delta = errors.at(j) * this->SigmoidDerivative(n->output);
      }
   }
}
double Network:: Activate(std::vector<double> weights,std::vector<double> inputs)
{
      double activation = weights.back(); // --> bias is the last value of weights vector
      for(size_t i = 0 ; i < weights.size() - 1 ; i++)
      {
         activation += weights[i] * inputs[i];
      }
      return activation;
}
double Network:: Sigmoid(double ActivationValue)
{
   return 1.0 / (1.0 + exp(-ActivationValue));
}
double Network:: SigmoidDerivative(double output)
{
  return output * (1 - output);
}

void Network:: UpdateWeights(DataContainer  *data)
{
     std::vector<double> inputs = *data->GetNormalizedVector();
     for(size_t i = 0 ;i <layers.size(); i ++)
     {
         if(i != 0)
         {
            for(Neuron *n : layers.at(i-1)->neurons)
            {
              inputs.push_back(n->output);
            }    
         }
         for(Neuron *n : layers.at(i)->neurons)
         {
            for(size_t j = 0 ; j< inputs.size();j++)
            {
               // function for updating weights for curr neuron
               n->weights.at(j) += this->learning_rate * n->delta * inputs.at(j);
            }
            // Updating bias
            n->weights.back() += this->learning_rate * n->delta;
         }
         inputs.clear(); 
     }

}
// Prediction value just by finding index of max val
int  Network::Predict(DataContainer *data)
{
   std::vector<double>outputs= FeedForward(data);
   // Distance is just calculating which index of element of outputs holds max value 
   return std::distance(outputs.begin(),std::max_element(outputs.begin(),outputs.end()));
}
void Network::Train(int epochs)
{
   std::cout << "In the process of training..."<<std::endl;
   for(int i = 0 ; i < epochs ;i++)
    {
      double sum_of_error= 0.0;
      for(DataContainer *data : *this->training_data)
      {
         std::vector<double> outputs =  FeedForward(data);
         std::vector<int>    expected = *data->GetClassVector();
         double temp_error_sum = 0.0;
         for(size_t j = 0 ; j < outputs.size();j++)
         {
            temp_error_sum += pow((double) expected.at(j) - outputs.at(j),2);
         }
         sum_of_error += temp_error_sum;
         BackPropagation(data);
         UpdateWeights(data);
      }
      cout << " Epoch: [" << i << "] | Error: [" <<sum_of_error<<"] " << endl;
   }
}

double Network::Test()
{
   double num_correct =0.0;
   double count = 0.0;
   cout << "Prediction " << endl;
   for(DataContainer *data : *this->test_data)
   {
      count ++;
      int index = Predict(data);
      if((int)count % 30 == 0)
      cout << data->GetClassVector()->at(index ) << " -> " << 1 << endl;
      if(data->GetClassVector()->at(index) == 1) num_correct++;
   }
   test_performance = (num_correct/count);
   return test_performance;
}
void  Network::Validate()
{
   double num_correct =0.0;
   double count = 0.0;
   for(DataContainer *data : *this->validation_data)
   {
      count ++;
      int index = Predict(data);
      if(data->GetClassVector()->at(index) == 1) num_correct++;
   }
   test_performance = (num_correct/count);
   cout << "Validation performance is : " << test_performance * 100 << "%"<<endl;
}