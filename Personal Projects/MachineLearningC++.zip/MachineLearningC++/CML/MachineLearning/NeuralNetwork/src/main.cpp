#include <iostream>
#include "Network.h"
#include "DataHandlers.h"
using namespace std;



int main(){
    DataHandlers *handlers = new DataHandlers();
    handlers->ReadCSV("../../../MNIST/iris.csv",',');
    // handlers->ReadFeaturesVector("../../../MNIST/train-images.idx3-ubyte");
    // handlers->ReadFeaturesLabel("../../../MNIST/train-labels.idx1-ubyte");
    // handlers->CountClasses();
    handlers->SplitData();
    vector<int>Layers={10};
    auto lambda = [&]()
    {
        Network *net = 
           new Network(
            Layers,
            handlers->GetTrainingData()->at(0)->GetNormalizedFeatureVectorSize(),
            handlers->GetNumberOfClasses(),
            0.25
           );
        net->SetTrainingData(handlers->GetTrainingData());
        net->SetTestData(handlers->GetTestData());
        net->SetValidationData(handlers->GetValidationData());
        net->Train(15);
        net->Validate();
        cout << "Test performance is : " << net->Test() * 100 << " % " << endl;
    };
    lambda();
    return 0;
}