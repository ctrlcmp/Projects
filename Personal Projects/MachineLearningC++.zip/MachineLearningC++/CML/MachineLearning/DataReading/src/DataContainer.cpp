
/////////////////////// DISCLAIMER //////////////////////////////////////////////////
//  Read : https://web.archive.org/web/20230128131234/http://yann.lecun.com/exdb/mnist/index.html
//  for all details about how MNIST data in file are being stored
//  it uses unsigned byte for storing grayscaled pixels hence we use uint8_t for values m= 
////////////////////////////////////////////////////////////////////////////////////


#include "DataContainer.h"

using namespace std;
DataContainer::DataContainer(){
  vector_of_features = new vector<uint8_t>;
  vector_of_double_features= new vector<double>;
}
DataContainer::~DataContainer(){
  delete vector_of_features;
  delete vector_of_double_features;
  delete vector_of_classes;
}
void DataContainer::SetFeatureVector(vector<uint8_t>* vect){
  vector_of_features = vect; 
}
//One hot encoded Vector of classes it is used for loss functions
void DataContainer::SetClassVector(int count){
  vector_of_classes = new vector<int>();
  for(int i = 0 ; i < count ; i++){
     if(i == label){
      // check
      // cout << i << " -> " << (int)label << endl;
      vector_of_classes->push_back(1);
     }
     else vector_of_classes->push_back(0);
  }
}
void DataContainer:: SetNormalizedFeatureVector(vector<double>* normalized){
  vector_of_double_features = normalized;
}
void DataContainer::AppendFeatureVector(uint8_t value){
  vector_of_features->push_back(value);
}
void DataContainer::AppendFeatureVector(double value){
  vector_of_double_features->push_back(value);
}
void DataContainer::SetLabel(uint8_t lbl){
  label = lbl;
}
void DataContainer::SetEnumeratedLabel(int newEnum){
 enum_label = newEnum;
}

int DataContainer::GetFeatureVectorSize(){
 return vector_of_features->size();
}
size_t DataContainer:: GetNormalizedFeatureVectorSize(){
  return this->vector_of_double_features->size();
}
int DataContainer::GetLabel(){
 return this->label;
}
uint8_t DataContainer::GetEnumeratedLabel(){
 return this->enum_label;
}
vector<uint8_t>*  DataContainer::GetVector(){
 return this->vector_of_features;
}
vector<double>*   DataContainer::GetNormalizedVector(){
  return this->vector_of_double_features;
}
vector<int>*  DataContainer::GetClassVector()
{
   return this->vector_of_classes;
}