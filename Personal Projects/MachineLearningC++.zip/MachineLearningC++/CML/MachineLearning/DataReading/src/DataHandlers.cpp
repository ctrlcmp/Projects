#include     "DataHandlers.h"
#include     "DataContainer.h"
#include     <random>
#include     <algorithm>


using namespace std;


   DataHandlers::DataHandlers(){
      training_data   = new vector<DataContainer*>;
      test_data       = new vector<DataContainer*>;
      validation_data = new vector<DataContainer*>;
   }
   DataHandlers::~DataHandlers(){
      delete training_data;
      delete test_data;
      delete validation_data;
      for(DataContainer * data : array_of_data){
         delete data;
      }

   }
   void DataHandlers::ReadCSV(string path,char delimiter){    
      num_of_classes = 0; 
      ifstream file(path.c_str());
      if(!file){
         cout << "File could not be oppened" << endl;
         exit(1);
      }
      string line="";
      string hline= "";
      string name="";
      int found = 0;
      while(getline(file,line)){
         if(line.length() == 0) continue;
         DataContainer *helper = new DataContainer();
         helper->SetNormalizedFeatureVector(new vector<double>);
         for(size_t i = 0 ; i < line.length(); i++){
            if(line[i] != delimiter && line[i]!='"' &&  !isalpha(line[i])){
               hline += line[i];
            }
            else {
               found = 1;
               if(isalpha(line[i]))name+=line[i];
            }
            if(found == 1){
               try{
                  if(hline.length()> 0)
                  helper->AppendFeatureVector(stod(hline));
      
               }
               catch(invalid_argument& e){
                    cerr << "Erorr while trying to parse  " <<endl;
                    exit(1);
               }
               hline = "";
               found = 0;
            }
         }

         // Setting distinct names of IRIS in label field
         // representing output layer of ANN
         if(map_of_Classes.find(name) != map_of_Classes.end())
         {
           helper->SetLabel(map_of_Classes[name]);
         }
         else
         {
            map_of_Classes[name] = num_of_classes;
            helper->SetLabel(map_of_Classes[name]);
            num_of_classes++;
         }
         array_of_data.push_back(helper);
         name="";
      }
      cout << " Successfully Read Csv file of size : " << array_of_data.size() << endl;

      cout << "Number of distinct classes is :" << num_of_classes << endl;

      for(DataContainer * data : array_of_data){
          data->SetClassVector(num_of_classes);
      } 
     feature_vector_size = array_of_data.at(0)->GetNormalizedVector()->size();
   }
   void DataHandlers::ReadFeaturesVector(string path){
        uint32_t headers[4];// MAGICNUM , IMAGESNUM, ROWS , COLUMNS
        unsigned char  bit_32[4];
        uint8_t  pixel[1];
        // binary file 
        FILE * file = fopen(path.c_str(),"rb");
        if(file == nullptr){
             cout << " Feature File could not be opened " << endl;
             exit(1);
        }
        // Parsing Headers
        for(int i = 0 ; i < 4; i++){
           if(fread(bit_32,sizeof(bit_32),1,file)){
              headers[i] = ConvertToLittleEndian(bit_32);
           }
        }
        cout << "Successfully Parsed Feature Headers" << endl;
        int number_of_images = headers[1];
        int size_of_image = headers[2]*headers[3];

        for(int i = 0 ; i < number_of_images ; i++){
            DataContainer* helper_vector = new DataContainer();
            for(int j = 0 ; j < size_of_image ; j++){
                 if(fread(pixel,sizeof(pixel),1,file)){
                    helper_vector->AppendFeatureVector(pixel[0]);
                 }
                 else {
                    cout << " Error with reading grayscalled pixels " << endl;
                    fclose(file);
                    exit(1); 
                 }
            }
            array_of_data.push_back(helper_vector);
            array_of_data.back()->SetClassVector(num_of_classes);
        }
        Normalize();
        cout << "WTF"<<endl;
        feature_vector_size = array_of_data.at(0)->GetFeatureVectorSize();
        cout << "Successfully Stored Pixelated images of number: " << array_of_data.size() << endl;
        fclose(file);
   } 

   void DataHandlers:: ReadFeaturesLabel(string path){
    uint32_t headers[2];// MAGICNUM , ITEMSNUM,
    unsigned char  bit_32[4];
    // binary file 
    FILE * file = fopen(path.c_str(),"rb");
    if(file == nullptr){
         cout << " Labels File could not be opened " << endl;
         exit(1);
    }
    // Parsing Headers
    for(int i = 0 ; i < 2; i++){
       if(fread(bit_32,sizeof(bit_32),1,file)){
          headers[i] = ConvertToLittleEndian(bit_32);
       }
    }
    cout << "Successfully Label Parsed Headers" << endl;
    int number_of_labels = headers[1];

    for(int i = 0 ; i < number_of_labels; i++){
        uint8_t lbl;
        if(fread(&lbl,sizeof(lbl),1,file)){
          array_of_data.at(i)->SetLabel(lbl);
        }
        else {
            cout << "Could not set Label name " << endl;
            fclose(file);
            exit(1);
        }
        
    }
   fclose(file);

   }
   
   void DataHandlers::SplitData(){
   // Separating original data
   int training_proportion = array_of_data.size() * TRAIN_SET_PERCENT;
   int test_proportion = array_of_data.size() * TEST_SET_PERCENT;
   int validation_proportion = array_of_data.size() * VALIDATION_SET_PERCENT;
   random_device rd;  // Seed for the random number generator
   default_random_engine rng(rd());
   shuffle(array_of_data.begin(), array_of_data.end(), rng);
   unordered_set<int>usedIndex;

   int counter = 0;
   int index=0;
   while(counter < training_proportion){
        training_data->push_back(array_of_data.at(index++));
        counter++;
       
   }

    counter = 0;
   while(counter < test_proportion){
        test_data->push_back(array_of_data.at(index++));
        counter++;
   }

   counter = 0;
   while(counter < validation_proportion){
        validation_data->push_back(array_of_data.at(index++));
        counter++;
   }
   cout << " Train dataset: " << training_data->size() << endl;
   cout << " Test dataset: " << test_data->size() << endl;
   cout << " Validation dataset: " << validation_data->size() << endl;
   }

   void DataHandlers:: CountClasses(){
    int counter=0;
      for(size_t i  = 0 ; i < array_of_data.size(); i++){
        // Finding all distinct label names using map
        // Setting enumerator for specific i-th place within array_of_data
         if(map_of_classes.find(array_of_data.at(i)->GetLabel()) == map_of_classes.end() ){
            map_of_classes[array_of_data.at(i)->GetLabel()] = counter;
            array_of_data.at(i)->SetEnumeratedLabel(counter);
            counter++;
         }
      }
      num_of_classes=counter;
      for(DataContainer * data : array_of_data)
      {
         data->SetClassVector(num_of_classes);
      }
      cout << "Number of distinct classes is : " << map_of_classes.size() << endl;
   }

   void DataHandlers::Normalize()
   {
      // Max min Normalizing 

      std::vector<double>mins,max;
      // We are just intializing vectors with values of feature vector or respective cfloat values
      for(auto val: *array_of_data.at(0)->GetVector()){
         mins.push_back(val);// or DBL_MAX cfloat lib
         max.push_back(val);//or -DBL_JMAX
      }
      // Here we're distributing and polarazing values to form two consecutive arrays 'maxs' and 'mins' 
      for(size_t i = 0;  i < array_of_data.size();i++)
      {
         DataContainer *d = array_of_data[i];
         for(int j = 0 ; j< d->GetFeatureVectorSize();j++)
         {
             if(d->GetVector()->at(j) > max[j]) max[j]  = d->GetVector()->at(j);
             if(d->GetVector()->at(j) < mins[j]) mins[j]  = d->GetVector()->at(j);       
         } 
      } 
      for(size_t i = 0;  i < array_of_data.size();i++)
      {
         // Initialazing vector of normalized features
         array_of_data[i]->SetNormalizedFeatureVector(new std::vector<double>());
         array_of_data[i]->SetClassVector(num_of_classes);
         for(int j = 0 ; j< array_of_data[i]->GetFeatureVectorSize();j++)
         {
             // This avoids dividing by zero 
             if(max[j] - mins[j] == 0) array_of_data[i]->AppendFeatureVector(0.0);
             else
             {
               // This is max min normalizing function
               // Before it val could be between 0-255 now its normalized to be 0.0 - 1.0
                double normalize_function = ((double)array_of_data[i]->GetVector()->at(j) - mins[j]) / (max[j] - mins[j]);
                array_of_data[i]->AppendFeatureVector(normalize_function);
             }
         } 
      } 
      
   } 

   int DataHandlers:: GetNumberOfClasses(){
    return this->num_of_classes;
   }
   vector<DataContainer*> *DataHandlers::  GetTrainingData(){
    return this->training_data;
   }
   vector<DataContainer*>*DataHandlers::  GetTestData(){
    return this->test_data;
   }
   vector<DataContainer*>*DataHandlers::  GetValidationData(){
    return this->validation_data;
   }
   uint32_t DataHandlers:: ConvertToLittleEndian(const unsigned char * bytes){
        return (uint32_t) ((bytes[0] << 24 ) | (bytes[1] << 16) | (bytes[2] << 8) | bytes[3]);
   }
