#include  <iostream>
#include "DataHandlers.h"
#include "DataContainer.h"

using namespace std;

int main(){

    DataContainer * data = new DataContainer();
    DataHandlers * handlers= new DataHandlers();
    handlers->ReadCSV("E:\\CML\\MNIST\\iris.csv",',');
    // handlers->ReadFeaturesVector("../../../../MNIST/train-images.idx3-ubyte");
    // handlers->ReadFeaturesLabel("../../../../MNIST/train-labels.idx1-ubyte");
    // handlers->SplitData();clea
    // handlers->CountClasses();
    


    cout << "Velicina naseg niza " << handlers->array_of_data.size() << endl;
    cout << "IRIS CSV: " << endl;
    for(DataContainer* data : handlers->array_of_data){
        for(double value : *data->GetDoubleVector()){
            cout << value << " ";
        }
        cout << endl;
    }
    delete data;
    delete handlers;
    return 0;
   }