#include "LearningData.h"



void    LearningData::SetTrainingData(std::vector<DataContainer *>* training){
    this->training_data=training;
}
void    LearningData::SetTestData(std::vector<DataContainer *>* test){
    this->test_data=test;
}
void    LearningData::SetValidationData(std::vector<DataContainer *>* validate ){
    this->validation_data=validate;
}