#ifndef __LEARNINGDATA_H
#define __LEARNINGDATA_H

#include "DataContainer.h"
#include <vector>


class LearningData{
   protected:
        std::vector<DataContainer *>    * training_data;
        std::vector<DataContainer *>    * test_data;
        std::vector<DataContainer *>    * validation_data;
   public:
        void                            SetTrainingData(std::vector<DataContainer *>* );
        void                            SetTestData(std::vector<DataContainer *>* );
        void                            SetValidationData(std::vector<DataContainer *>* );

};

#endif // __LEARNINGDATA_H