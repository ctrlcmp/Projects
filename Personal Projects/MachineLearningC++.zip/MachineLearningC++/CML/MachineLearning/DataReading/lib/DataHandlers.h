#ifndef DATAHANDLER
#define DATAHANDLER


#include                  <iostream>
#include                  <vector>
#include                  <string>
#include                  <fstream>
#include                  <map>
#include                  <unordered_set>
#include                  "stdint.h"
#include                  "stdio.h"
#include                  <cctype>
#include                  "DataContainer.h"
using namespace std;

#define TRAIN_SET_PERCENT 0.75
#define TEST_SET_PERCENT 0.20
#define VALIDATION_SET_PERCENT 0.05


class DataHandlers{
  private:
   vector<DataContainer *>    *training_data;
   vector<DataContainer *>    *test_data;
   vector<DataContainer *>    *validation_data;  
   map<uint8_t,int>           map_of_classes;
   map<string,int>            map_of_Classes;
   int                        num_of_classes;
   int                        feature_vector_size;
  public:
   vector<DataContainer *>    array_of_data;
   DataHandlers();
   ~DataHandlers();
   void                       ReadCSV(string path,char delimiter);
   void                       ReadFeaturesVector(string path);
   void                       ReadFeaturesLabel(string path);
   void                       SplitData();
   void                       CountClasses();
   void                       Normalize();
   vector<DataContainer*>     *GetTrainingData();
   vector<DataContainer*>     *GetTestData();
   vector<DataContainer*>     *GetValidationData();
   uint32_t                   ConvertToLittleEndian(const unsigned char *);
   int                        GetNumberOfClasses();
   int                        GetFeatureVectorSize();
   


};


#endif