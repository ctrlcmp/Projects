#ifndef DATACONTAINER_H
#define DATACONTAINER_H

#include <iostream>
#include <vector>
#include "stdint.h"
#include "stdio.h"
#include <fstream>

using namespace std;


class DataContainer{

    private:
      vector <uint8_t>    * vector_of_features;
      vector <double>     * vector_of_double_features;
      vector <int>        * vector_of_classes;
      uint8_t               label;
      int                   enum_label;

    
    public:
                          DataContainer();
                          ~DataContainer();
                  
      void                SetFeatureVector(vector<uint8_t>*);
      void                SetClassVector(int);
      void                SetNormalizedFeatureVector(vector<double>*);
      void                AppendFeatureVector(uint8_t);
      void                AppendFeatureVector(double);
      void                SetLabel(uint8_t);
      void                SetEnumeratedLabel(int); 

      int                 GetFeatureVectorSize();
      size_t              GetNormalizedFeatureVectorSize();
      int                 GetLabel();
      uint8_t             GetEnumeratedLabel();

      vector<uint8_t>*    GetVector();
      vector<double>*     GetNormalizedVector();
      vector<int>*        GetClassVector();

};   
#endif // DATACONTAINER_H